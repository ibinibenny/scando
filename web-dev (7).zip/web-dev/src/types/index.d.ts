export {};

declare global {
  interface Window {
    AgoraEduSDK: any;
  }
}