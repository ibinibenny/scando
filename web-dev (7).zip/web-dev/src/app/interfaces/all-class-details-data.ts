interface End {
    hour: number;
    min: number;
}

interface Start {
    hour: number;
    min: number;
}

export interface TimeTable {
    end: End;
    start: Start;
    day: string;
}

interface Activity {
    doubtSession: number;
    scheduledTest: number;
    homeWork: number;
    notice: number;
}

interface StudyMaterials {
    documentCount: number;
    voiceCount: number;
    videoCount: number;
}

export interface AllClassDetailsData {
    classId: number;
    className: string;
    classType: number;
    isScheduled: number;
    timeTable: TimeTable[];
    activity: Activity;
    studyMaterials: StudyMaterials;
    classRecordings: number;
    message: string;
    enrolledStudents: number;
    isEnrolled?: number;
    subAccountId: string;
    feePaymentType: number;
    feeCollectionType: number;
    feePaymentTimeLine: number;
    feeAmount : number;
    lastFeePaymentDate: number;
    lastFeePaymentMonth: number;
    isPaymentValid: boolean;
}
