export interface FeeStructure {
    classId: number;
    userId: number;
    feePaymentType: number;
    feeAmount: number;
    feeCollectionType: number;
    feePaymentTimeLine: number;
    feeReminder: number;
    feeDescription: string;
    publishStatus: number;
}
