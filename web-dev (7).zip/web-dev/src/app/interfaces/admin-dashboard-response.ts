export interface AllOnlineUsers {
  studentCount: number;
  teacherCount: number;
  adminCount: number;
}

export interface AllClassTypesInfo {
  classType: number;
  userCount: number;
  hostCount: number;
  classCount: number;
}

export interface GetPastActivities {
  tuition: number;
  hobbies: number;
  events: number;
  others: number;
}

export interface GetAllRegisteredUsers {
  registeredStudents: number;
  registeredTeachers: number;
}

export interface AverageLaunchTime {
  averageTime: number;
}

// export interface AdminProperties {
//   property: string;
// }
export interface AdminProperties {
    activityLocation: boolean;
		liveScheduleGraph: boolean;
		onlineUsers: boolean;
		avgTimeAnalytics: boolean;
}