export interface SpecificDayClassTeacher {
    classId: number;
    classType: number;
    className: string;
    teacherId: number;
    timeTable: TimeTable[];
    isScheduled: number;
    documents: number;
    doubtSession: number;
    message: string;
    enrolledStudents: number;
    activity: Activity;
}

interface End {
    hour: number;
    min: number;
}

interface Start {
    hour: number;
    min: number;
}

export interface Activity {
    doubtSession: number;
    scheduledTest: number;
    homeWork: number;
    notice: number;
}

export interface TimeTable {
    end: End;
    start: Start;
    day: string;
}
