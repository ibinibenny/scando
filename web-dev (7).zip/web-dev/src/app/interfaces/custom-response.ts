export interface CustomResponse {
    data: any;
    statusCode: number;
    message: string;
    success: boolean;
    completeResponse: any;
}
