export interface ReceiptData {
    classId: number;
    className: string;
    subjectName: string;
    teacherName: string;
    classType: number;
    billDate: number;
    paymentDate: number;
    fee: number;
    total: number;
    uniqueOrderId: string;
    orderId: number;
}
