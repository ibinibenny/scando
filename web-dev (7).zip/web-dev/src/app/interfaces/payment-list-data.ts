export interface PaymentListData {
    studentId: number;
    studentName: string;
    paymentDate: number;
    paymentChannel: string;
    amount: number;
}
