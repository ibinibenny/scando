interface Activity {
  doubtSession: number;
  scheduledTest: number;
  homeWork: number;
  notice: number;
}

interface StudyMaterials {
  documentCount: number;
  voiceCount: number;
  videoCount: number;
}

export interface EnrolledClassData {
  classId: number;
  days: number[];
  startTime: number;
  endTime: number;
  activity: Activity;
  studyMaterials: StudyMaterials;
}
