interface End {
  hour: number;
  min: number;
}

interface Start {
  hour: number;
  min: number;
}

interface TimeTable {
  end: End;
  start: Start;
  day: string;
}

interface Activity {
  doubtSession: number;
  scheduledTest: number;
  homeWork: number;
  notice: number;
}

interface StudyMaterials {
  documentCount: number;
  voiceCount: number;
  videoCount: number;
}

export interface SpecificClassDetailsData {
  classId: number;
  className: string;
  subjectName: string;
  classType: number;
  isScheduled: number;
  timeTable: TimeTable[];
  activity: Activity;
  studyMaterials: StudyMaterials;
  classRecordings: number;
  message: string;
}
