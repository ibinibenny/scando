export interface ApprovalListData {
  enrollId: number;
  classId: number;
  studentId: number;
  enrollTime: number;
  studentName: string;
  phoneNumber: string;
  enrollStatus: number;
}
