export interface TeacherBankAccount {
    userId: number;
    accountId: number;
    accountNumber: string;
    accountBank: string;
    subAccountId: string;
    bankName: string;
    splitType: string;
    splitValue: string;
    isPrimaryAccount: number;
}
