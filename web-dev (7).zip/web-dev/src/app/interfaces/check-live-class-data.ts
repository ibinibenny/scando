export interface CheckLiveClassData {
  classStatus: boolean;
  message: string;
  code: number;
}
