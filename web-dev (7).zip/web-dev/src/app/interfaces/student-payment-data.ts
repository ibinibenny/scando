export interface StudentPaymentData {
    studentId: number;
    className: string;
    paymentDate: number;
    paymentChannel: string;
    amount: number;
    status: number;
    orderId: string;
}
