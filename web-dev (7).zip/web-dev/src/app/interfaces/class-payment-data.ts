export interface ClassPaymentData {
    classId: number;
    className: string;
    teacher: string;
    subAccountId: string;
    billDate: number;
    fee: number;
    fine: number;
    total: number;
}
