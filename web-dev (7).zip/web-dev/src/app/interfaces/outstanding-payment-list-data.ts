export interface OutstandingPaymentListData {
    studentId: number;
    studentName: string;
    lastPaymentDate: number;
    feePaymentTimeLine: number;
    feePaymentType: number;
    feeCollectionType: number;
}
