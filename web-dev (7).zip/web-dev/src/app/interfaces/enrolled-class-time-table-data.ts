export interface EnrolledClassTimeTableData {
  timeTableId: number;
  classRoomId: number;
  days: number[];
  repeatEnabled: boolean;
}
