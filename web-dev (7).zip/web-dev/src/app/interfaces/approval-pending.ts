export interface EnrolmentPendingData {
    enrollId: number;
    classId: number;
    enrollTime: any;
    className: string;
    teacherId: number;
    enrollStatus: number;
    subjectName: string;
}



