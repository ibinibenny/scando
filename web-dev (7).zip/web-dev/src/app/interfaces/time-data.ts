export interface TimeData {
    hour: number;
    min: number;
}
