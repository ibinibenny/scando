export interface TimeTableData {
  timeTableId: number;
  classRoomId: number;
  days: number[];
  repeatEnabled: boolean;
}
