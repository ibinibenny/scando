interface StudyMaterials {
  documentCount: number;
  voiceCount: number;
  videoCount: number;
}

export interface SpecificClassRoomData {
  className: string;
  timetableEnabled: boolean;
  enrolledStudents: number;
  classRecordings: number;
  studyMaterials: StudyMaterials;
}
