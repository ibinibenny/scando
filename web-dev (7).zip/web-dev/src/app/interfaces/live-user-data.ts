import { ICameraVideoTrack, IMicrophoneAudioTrack, IRemoteAudioTrack, IRemoteVideoTrack } from "agora-rtc-sdk-ng";

export interface LiveUserData {
    id: number;
    audio?: IRemoteAudioTrack;
    video?: IRemoteVideoTrack;
    name?: string;
    role?: string;
}
