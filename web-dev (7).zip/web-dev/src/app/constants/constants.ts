import { environment } from 'src/environments/environment';

export const Constants = {
  URL: {
    // ----- API's RELATED TO ADMIN -----
    ADMIN_LOGIN: `${environment.ADMIN_API_URL}/admin/login`,
    ACTIVITY_COMPLETION_STATUS: `${environment.ADMIN_API_URL}/admin/activity-completion-status`,
    CLASS_TYPE_COUNT: `${environment.ADMIN_API_URL}/admin/class-type-count`,
    CLASS_TYPE_INFO: `${environment.ADMIN_API_URL}/admin/class-type-info`,
    AVERAGE_TIME_LAUNCH: `${environment.ADMIN_API_URL}/admin/class/average-time-launch`,
    GET_ONLINE_USER_COUNT: `${environment.ADMIN_API_URL}/admin/get-online-user-count`,
    LIVE_SCHEDULE_COUNT: `${environment.ADMIN_API_URL}/admin/live-schedule-count`,
    GET_PROPERTY: `${environment.ADMIN_API_URL}/admin/property/get`,
    SAVE_PROPERTY: `${environment.ADMIN_API_URL}/admin/property/save`,
    USER_STATUS_COUNT: `${environment.ADMIN_API_URL}/admin/user-status-count`,

    // ----- API's RELATED TO USER AUTHENTICATION -----
    APP_REGISTRATION: `${environment.API_URL}/app/registration`, // --- To registering the app

    // ----- API's RELATED TO LOGGED_IN USER -----
    PROFILE_UPLOAD: `${environment.API_URL}/auth/profile-upload`, // --- To upload profile
    VERIFY_OTP: `${environment.API_URL}/auth/verify-otp`, // --- To verify Otp
    CHECK_ACCOUNT: `${environment.API_URL}/auth/check-account`, // --- To check the account exits or not
    GENERATE_OTP: `${environment.API_URL}/auth/generate-otp`, // --- To generate Otp

    // ----- API's RELATED TO STUDENTS -----
    CHECK_LIVE_CLASSES: `${environment.API_URL}/student/check-liveClass`, // --- To check the class is live or Not
    ENROLL_CLASS: `${environment.API_URL}/student/enroll-class`, // --- To enroll student  class
    ENROLLED_CLASS: `${environment.API_URL}/student/enrolled-class`, // --- To get enrolled classes
    ENROLLED_CLASSES_TIMETABLE: `${environment.API_URL}/student/enrolled-classes-timetable`, // --- To get enrolled class timetable
    // SCHEDULED_CLASS: `${environment.API_URL}/student/scheduled-class`, // --- To get scheduled classes
    STUDENT_SIGNUP: `${environment.API_URL}/auth/student/signup`, // --- To student signup
    STUDENT_UN_ENROLL: `${environment.API_URL}/student/Un-enroll`, // --- To student un-enroll class
    GET_STUDENT_OWN_CLASS: `${environment.API_URL}/student/own-class`, // --- To student own-class
    GET_STUDENT_ALL_CLASS_DETAILS: `${environment.API_URL}/student/all-class-details`, // --- To get student all class details
    GET_STUDENT_CLASS_DETAILS: `${environment.API_URL}/student/class-details`, // --- To get student class details
    GET_ENROLL_STATUS: `${environment.API_URL}/student/enroll-list`, // --- To get enrolled classes and waiting classes

    // ----- API's RELATED TO TEACHERS -----
    GET_TIME_TABLE: `${environment.API_URL}/get-timetable`, // --- To get timetable
    APPROVAL_LIST: `${environment.API_URL}/teacher/approval-list`, // --- To get list of approval of students
    APPROVE: `${environment.API_URL}/teacher/approve`, // --- To approve student for a class
    CREATE_CLASS_ROOM: `${environment.API_URL}/teacher/create-classroom`, // --- To create / edit classroom
    UPDATE_CLASS_ROOM: `${environment.API_URL}/teacher/update-classroom`,
    CREATE_TIME_TABLE: `${environment.API_URL}/teacher/create-timetable`, // --- To create / update timetable
    DELETE_CLASS_ROOM: `${environment.API_URL}/teacher/delete-classroom`, // --- To delete classroom
    // GET_CLASS_ROOM: `${environment.API_URL}/teacher/get-classroom`, // --- To get specific class room details
    GET_SCHEDULED_CLASS: `${environment.API_URL}/teacher/scheduled-class`, // --- To get scheduled classes of the teacher
    TEACHER_SIGNUP: `${environment.API_URL}/auth/teacher/signup`, // --- To teacher signup
    TEACHER_UN_ENROLL: `${environment.API_URL}/teacher/Un-enroll`, // --- To un-enroll the student from a class
    GET_ALL_CLASSES_TEACHER: `${environment.API_URL}/teacher/all-class`, // --- To get all classes of a Teacher
    GET_ALL_CLASS_DETAILS_TEACHER: `${environment.API_URL}/teacher/all-class-details`, // --- To get all classes of a Teacher
    GET_ALL_OWN_CLASSES_TEACHER: `${environment.API_URL}/teacher/own-class`, // --- To get all classes of a Teacher
    GET_CLASS_SPECIFIC_DETAILS: `${environment.API_URL}/teacher/class-details`, // --- To get details of specific class
    UPDATE_CLASSROOM: `${environment.API_URL}/teacher/update-classroom`, // --- To update class room details
    TEACHER_GET_CLASS_SPECIFIC_DAY: `${environment.API_URL}/teacher/class-specific-day`,

    // ----- API's RELATED TO AGORA AUTHENTICATION -----
    GET_RTC_TOKEN: `${environment.API_URL}/agora/rtc-token`,
    GET_RTM_TOKEN: `${environment.API_URL}/agora/rtm-token`,

    // ----- API's RELATED TO AGORA CONTROLLER -----
    CHECK_CLASS_STATUS: `${environment.API_URL}/agora/check-class-status`,
    GET_EVENT_STATUS: `${environment.API_URL}/agora/get-event-status`,
    GET_PUBLIC_RESOURCES: `${environment.API_URL}/agora/get-public-resources`,
    GET_RECORDING_LIST: `${environment.API_URL}/agora/get-recording-list`,

    // PAYMENT APIS
    TEACHER_GET_ACCOUNT_LIST: `${environment.API_URL}/teacher/payment/bank-detail-list`,
    GET_FEE_STRUCTURE: `${environment.API_URL}/teacher/payment/get-fee-detail`,
    CREATE_FEE_STRUCTURE: `${environment.API_URL}/teacher/payment/add-fee-details`,
    UPDATE_FEE_STRUCTURE: `${environment.API_URL}/teacher/payment/update-fee-details`,
    GET_FEE_COLLECTED: `${environment.API_URL}/teacher/payment/fees-collected`,
    GET_FEE_OUTSTANDING: `${environment.API_URL}/teacher/payment/fees-out-standing`,
    SEND_REMINDER: `${environment.API_URL}/teacher/notification/send`,
    ADD_BANK_ACCOUNT: `${environment.API_URL}/teacher/payment/add-bank-account`,
    UPDATE_BANK_ACCOUNT: `${environment.API_URL}/teacher/payment/update-bank-account`,
    CREATE_ORDER_ID: `${environment.API_URL}/student/payment/create-order-id`,
    UPDATE_ORDER_ID: `${environment.API_URL}/student/payment/update-order-id`,
    DELETE_BANK_ACCOUNT: `${environment.API_URL}/teacher/payment/delete-bank-account`,
    GET_PAYMENT_DETAILS: `${environment.API_URL}/student/payment/get-payment-details`,
    GET_RECEIPT: `${environment.API_URL}/student/payment/receipt`,
    GET_SELF_PAYMENTS: `${environment.API_URL}/student/payment/my-payment-list`,
    TEACHER_CLASS_STARTED: `${environment.API_URL}/teacher/launch-class`,
    TEACHER_CLASS_ENDED: `${environment.API_URL}/teacher/end-class`,
    STUDENT_CLASS_STARTED: `${environment.API_URL}/student/start-class`,
    STUDENT_CLASS_ENDED: `${environment.API_URL}/student/end-class`,
  },
  STRINGS: {
    TOKEN: 'token',
    APP_ID: 'scando_app_id',
    USER_ID: 'userId',
    USER_TYPE: 'userType',
    USERNAME: 'userName',
    TEACHER: 'teacher',
    STUDENT: 'student'
  },
  STATUS_CODES: {
    SUCCESS: 20001,
    UNAUTHORIZED: 40001,
  },
  VERSION: '1.0.0',
  AGORA: {
    APP_ID: 'e960991294b64b37aef68d8c00824c26',
    APP_CERTIFICATE: '3f927983e2f84c9e92655d48875cf782',
  },
  FLUTTERWAVE: {
    PUBLIC_KEY: 'FLWPUBK_TEST-e15b54c6e16597f75d7538a46e793ede-X',
    SECRET_KEY: 'FLWSECK_TEST-6b88fb4010560d2f74eedc378f3f2300-X',
  }
};
