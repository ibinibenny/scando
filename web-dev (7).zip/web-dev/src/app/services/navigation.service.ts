import { Injectable } from '@angular/core';
import {Location} from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class NavigationService {

  constructor(
    private _location: Location
  ) { }

  public goBack() {
    this._location.back();
  }

}
