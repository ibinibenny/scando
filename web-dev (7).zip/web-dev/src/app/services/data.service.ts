import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { StorageService } from './storage.service';
import { catchError, map, retry } from 'rxjs/operators';
import { CustomResponse } from '../interfaces/custom-response';
import { Constants } from '../constants/constants';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(
    private http: HttpClient,
    private storageService: StorageService
  ) { }

  public parseApiCall(
    url: string,
    method: string,
    data: any,
    header: {
      headers?: HttpHeaders | {
        [header: string]: string | string[];
      }; observe?: 'body'; params?: HttpParams | {
        [param: string]: string | string[]; }; reportProgress?: boolean; responseType?: 'json'; withCredentials?: boolean; }
  ): Observable<CustomResponse> {
    switch (method) {
      case 'GET':
        return this.http.get(url, header)
          .pipe(
            retry(2),
            map(res => DataService.parseResponse(res)),
            catchError(err => this.handleError(err))
          );
          // .pipe(
          //   retry(2),
          //   map(res => ResponseChecker.parseResponse(res, this.backendType, isGzip)),
          //   catchError(err => this.errorHandlerService.handleError(err, reloadOnUnauth))
          // );

      case 'POST':
        return this.http.post(url, data, header)
          .pipe(
            retry(2),
            map(res => DataService.parseResponse(res)),
            catchError(err => this.handleError(err))
          );
          // .pipe(
          //   // retry(2),
          //   map(res => ResponseChecker.parseResponse(res, this.backendType, isGzip)),
          //   catchError(err => this.errorHandlerService.handleError(err, reloadOnUnauth))
          // );

      case 'PUT':
        return this.http.put(url, data, header)
          .pipe(
            retry(2),
            map(res => DataService.parseResponse(res)),
            catchError(err => this.handleError(err))
          );
          // .pipe(
          //   // retry(2),
          //   map(res => ResponseChecker.parseResponse(res, this.backendType, isGzip)),
          //   catchError(err => this.errorHandlerService.handleError(err, reloadOnUnauth))
          // );

      case 'DELETE':
        return this.http.delete(url, {headers: header.headers, body: data})
          .pipe(
            retry(2),
            map(res => DataService.parseResponse(res)),
            catchError(err => this.handleError(err))
          );
          // .pipe(
          //   // retry(2),
          //   map(res => ResponseChecker.parseResponse(res, this.backendType, isGzip)),
          //   catchError(err => this.errorHandlerService.handleError(err, reloadOnUnauth))
          // );

      default:
        console.error('Invalid method');
        return of({
          data: [],
          success: false,
          completeResponse: null,
          message: 'Invalid method',
          statusCode: 0
        });
    }
  }

  public static parseResponse(response: any): CustomResponse {
    if (this.isResponseStatusSuccess(response)) {
      return {
        data: response.data,
        statusCode: response.status.statusCode,
        message: response.status.statusMessage,
        success: true,
        completeResponse: response
      };
    } else {
      return {
        data: [],
        statusCode: response.status.statusCode,
        message: response.data.message,
        success: false,
        completeResponse: response
      };
    }
  }

  private handleError(error: HttpErrorResponse): Observable<CustomResponse> {
    console.error(error);
    if (error.error instanceof ErrorEvent) {
      // this.toastr.error(error.error.message, 'Error');
      return of({data: [], message: error.error.message, statusCode: error.status, success: false, completeResponse: error.error});
    } else {
      let errorMessage;
      if (error.status === 500) {
        errorMessage = 'Something went wrong. Please contact system admin';
      } else {
        errorMessage = error.statusText;
      }
      return of({
        data: [],
        message: errorMessage,
        statusCode: error.status,
        success: false,
        completeResponse: error.error
      });
    }
  }

  private checkUnAuthorized(status: number): boolean {
    if (Number(status) === Constants.STATUS_CODES.UNAUTHORIZED) {
      sessionStorage.removeItem(Constants.STRINGS.TOKEN);
      location.reload();
      return true;
    } else {
      return false;
    }
  }

  private static isResponseStatusSuccess(response: any): boolean {
    return Number(response.status.statusCode) === Constants.STATUS_CODES.SUCCESS;
  }

  public getTokenHeader(): {
    headers?: HttpHeaders | {
      [header: string]: string | string[];
    }; observe?: 'body'; params?: HttpParams | {
      [param: string]: string | string[];
    }; reportProgress?: boolean; responseType?: 'json'; withCredentials?: boolean;
  } {
    const token = this.storageService.getSessionStorage(Constants.STRINGS.TOKEN);
    const httpOptions = {
      headers: new HttpHeaders({
        Accept: 'application/json',
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      }), withCredentials: true
    };
    return httpOptions;
  }

  public getTokenHeaderMultipart(): {
    headers?: HttpHeaders | {
      [header: string]: string | string[];
    }; observe?: 'body'; params?: HttpParams | {
      [param: string]: string | string[];
    }; reportProgress?: boolean; responseType?: 'json'; withCredentials?: boolean;
  } {
    const token = this.storageService.getSessionStorage(Constants.STRINGS.TOKEN);
    const httpOptions = {
      headers: new HttpHeaders({
        Accept: 'application/json',
        Authorization: `Bearer ${token}`
      }), withCredentials: true
    };
    return httpOptions;
  }

  public getCommonHeader() {
    const commonHeader = {
      headers: new HttpHeaders(
        {
          'Content-Type': 'application/json',
          accept: 'application/json'
        }
      )
    };
    return commonHeader;
  }

  public getCommonHeaderMultipart() {
    const commonHeader = {
      headers: new HttpHeaders(
        {
          accept: 'application/json'
        }
      )
    };
    return commonHeader;
  }
}
