import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  constructor() { }

  public setSessionStorage(key: string, data: any): void {
    sessionStorage.setItem(key, JSON.stringify(data));
  }

  public setLocalStorage(key: string, data: any): void {
    localStorage.setItem(key, JSON.stringify(data));
  }

  public getSessionStorage(key: string): any {
    const item = sessionStorage.getItem(key);
    if (item) {
      console.log('item:',item);
      return JSON.parse(item);
    } else {
      return null;
    }

  }

  public getLocalStorage(key: string): any {
    const item = localStorage.getItem(key);
    if (item) {
      return JSON.parse(item);
    } else {
      return null;
    }
  }

  public isKeyExistInLocal(key: string) {
    return localStorage.getItem(key) != null;
  }

  public isKeyExistInSession(key: string) {
    return sessionStorage.getItem(key) != null;
  }

}
