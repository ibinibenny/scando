import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';
import { LoginComponent } from './modules/auth/login/login.component';
import { OtpVerificationComponent } from './modules/auth/otp-verification/otp-verification.component';
import { SignupLoginComponent } from './modules/auth/signup-login/signup-login.component';
import { StudentSignupComponent } from './modules/auth/student-signup/student-signup.component';
import { TeacherSignupComponent } from './modules/auth/teacher-signup/teacher-signup.component';
import { ContainerComponent } from './modules/global/container/container.component';
import { StudentContainerComponent } from './modules/global/student-container/student-container.component';
import { AdminDashboardComponent } from './modules/admin/admin-dashboard/admin-dashboard.component';
import { AdminSignupComponent } from './modules/auth/admin-signup/admin-signup.component';
import { AdminSettingsComponent } from './modules/admin/admin-settings/admin-settings.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'login'
  },
  {
    path: 'manage-widgets',
    component: AdminSettingsComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'admin',
    canActivate: [AuthGuard],
    component: AdminDashboardComponent,
  },
  {
    path: 'login/3',
    component: AdminSignupComponent
  },
  {
    path: 'login/:type',
    component: SignupLoginComponent
  },
  {
    path: 'login/:type/:mobile',
    component: OtpVerificationComponent
  },

  {
    path: 'login/1/:mobile/signup',
    component: TeacherSignupComponent
  },
  {
    path: 'login/2/:mobile/signup',
    component: StudentSignupComponent
  },
  {
    path: 'teacher',
    component: ContainerComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: 'dashboard',
        loadChildren: () => import('./modules/dashboard/dashboard.module').then(m => m.DashboardModule)
      },
      {
        path: 'manage-class',
        loadChildren: () => import('./modules/manage-class/manage-class.module').then(m => m.ManageClassModule)
      },
      {
        path: 'payment',
        loadChildren: () => import('./modules/teacher-payments/teacher-payments.module').then(m => m.TeacherPaymentsModule)
      }
    ]
  },
  {
    path: 'student',
    component: StudentContainerComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: 'dashboard',
        loadChildren: () => import('./modules/student-dashboard/student-dashboard.module').then(m => m.StudentDashboardModule)
      },
      {
        path: 'class',
        loadChildren: () => import('./modules/student-class/student-class.module').then(m => m.StudentClassModule)
      },
      {
        path: 'payment',
        loadChildren: () => import('./modules/student-payments/student-payments.module').then(m => m.StudentPaymentsModule)
      }
    ]
  },
  {
    path: 'liveclass',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/liveclass/liveclass.module').then(m => m.LiveclassModule)
  },
  {
    path: 'modify-class',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/modify-class/modify-class.module').then(m => m.ModifyClassModule)
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
