import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RouterModule } from '@angular/router';
import { GlobalModule } from './modules/global/global.module';
import { ContainerComponent } from './modules/global/container/container.component';
import { HttpClientModule } from '@angular/common/http';
import { DeviceDetectorService } from 'ngx-device-detector';
import { StudentContainerComponent } from './modules/global/student-container/student-container.component';
import { FormsModule } from '@angular/forms';
import { ClipboardModule } from 'ngx-clipboard';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { AuthModule } from './modules/auth/auth.module';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { LoadingBarHttpClientModule } from '@ngx-loading-bar/http-client';
import { FooterComponent } from './modules/global/footer/footer.component';
import { AdminModule } from './modules/admin/admin.module';
import { NgApexchartsModule } from 'ng-apexcharts';
import { TabsModule } from 'ngx-bootstrap/tabs';


@NgModule({
  declarations: [
    AppComponent,
    ContainerComponent,
    StudentContainerComponent,
    FooterComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    RouterModule,
    GlobalModule,
    HttpClientModule,
    FormsModule,
    ClipboardModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    AuthModule,
    NgxMaterialTimepickerModule,
    LoadingBarHttpClientModule,
    AdminModule,
    NgApexchartsModule,
    TabsModule,
  ],
  providers: [DeviceDetectorService],
  bootstrap: [AppComponent]
})
export class AppModule { }
