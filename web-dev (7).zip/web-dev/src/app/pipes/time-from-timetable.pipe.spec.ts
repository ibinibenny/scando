import { TimeFromTimetablePipe } from './time-from-timetable.pipe';

describe('TimeFromTimetablePipe', () => {
  it('create an instance', () => {
    const pipe = new TimeFromTimetablePipe();
    expect(pipe).toBeTruthy();
  });
});
