import { formatDate } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'timeToTwelveFormat'
})
export class TimeToTwelveFormatPipe implements PipeTransform {

  transform(value: string): string {
    if (value) {
      try {
        const date = new Date();
        const hour = Number(value.split(':')[0]);
        const minute = Number(value.split(':')[1]);
        date.setHours(hour, minute, 0, 0);
        return formatDate(date, 'hh:mm aa', 'en');
      } catch (error) {
        return value;
      }
    } else {
      return '';
    }
  }

}
