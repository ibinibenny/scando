import { Pipe, PipeTransform } from '@angular/core';
import { Activity } from '../interfaces/specific-day-class-teacher';

@Pipe({
  name: 'activityList'
})
export class ActivityListPipe implements PipeTransform {

  transform(value: Activity, withNumber: boolean): string[] {
    if (value) {
      const data = [];
      if (value.doubtSession) {
        data.push(`${withNumber?value.doubtSession:''} Active Doubt Session`);
      }
      if (value.homeWork) {
        data.push(`${withNumber?value.homeWork:''} Home Work Assigned`);
      }
      if (value.notice) {
        data.push(`${withNumber?value.notice:''} Notice`);
      }
      if (value.scheduledTest) {
        data.push(`${withNumber?value.scheduledTest:''} Scheduled Test`);
      }
      return data;
    }
    return [];
  }

}
