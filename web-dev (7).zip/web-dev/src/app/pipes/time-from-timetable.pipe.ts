import { Pipe, PipeTransform } from '@angular/core';
import { TimeTable } from '../interfaces/all-class-details-data';

@Pipe({
  name: 'timeFromTimetable'
})
export class TimeFromTimetablePipe implements PipeTransform {

  transform(value: TimeTable[]|undefined, ...args: unknown[]): string {
    if (value) {
      try {
        let duration = 0;
        value.forEach(element => {
          duration = duration + (Number(element.end.hour * 60)+Number(element.end.min)) - (Number(element.start.hour * 60)+Number(element.start.min));
        });
        return `${Math.floor(duration/60)}:${String(duration%60).padStart(2,'0')}`;
      } catch (error) {
        return '00:00'
      }
    } else {
      return '';
    }
  }

}
