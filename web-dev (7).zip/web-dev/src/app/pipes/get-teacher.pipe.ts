import { Pipe, PipeTransform } from '@angular/core';
import { IAgoraRTCRemoteUser, IRemoteVideoTrack } from 'agora-rtc-sdk-ng';

@Pipe({
  name: 'getTeacher',
  pure: false
})
export class GetTeacherPipe implements PipeTransform {

  transform(value: IAgoraRTCRemoteUser[]): IRemoteVideoTrack {
    const filtered = value.filter(single => single.videoTrack != null);
    if (filtered.length === 0) {
      return null;
    } else {
      return filtered[0].videoTrack;
    }
  }

}
