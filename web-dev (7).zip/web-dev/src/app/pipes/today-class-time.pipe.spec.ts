import { TodayClassTimePipe } from './today-class-time.pipe';

describe('TodayClassTimePipe', () => {
  it('create an instance', () => {
    const pipe = new TodayClassTimePipe();
    expect(pipe).toBeTruthy();
  });
});
