import { GetTeacherPipe } from './get-teacher.pipe';

describe('GetTeacherPipe', () => {
  it('create an instance', () => {
    const pipe = new GetTeacherPipe();
    expect(pipe).toBeTruthy();
  });
});
