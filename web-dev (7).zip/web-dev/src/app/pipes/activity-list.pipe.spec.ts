import { ActivityListPipe } from './activity-list.pipe';

describe('ActivityListPipe', () => {
  it('create an instance', () => {
    const pipe = new ActivityListPipe();
    expect(pipe).toBeTruthy();
  });
});
