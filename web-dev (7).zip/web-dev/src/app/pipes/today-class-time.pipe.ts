import { formatDate } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';
import { TimeTable } from '../interfaces/all-class-details-data';

@Pipe({
  name: 'todayClassTime'
})
export class TodayClassTimePipe implements PipeTransform {

  transform(value: TimeTable[]|undefined): string {
    if (value) {
      const today = new Date();
      const todayTimeTable = value?.filter(single => {
        return single.day === `0${today.getDay() === 0 ? 7 : today.getDay()}`;
      })[0];
      const startDate = new Date();
      const endDate = new Date();
      startDate.setHours(todayTimeTable?.start.hour,todayTimeTable?.start.min,0,0);
      endDate.setHours(todayTimeTable?.end.hour,todayTimeTable?.end.min,0,0);
      return `${formatDate(startDate,'hh.mm aa','en')} - ${formatDate(endDate,'hh.mm aa','en')}`;
    } else {
      return '';
    }
  }

}
