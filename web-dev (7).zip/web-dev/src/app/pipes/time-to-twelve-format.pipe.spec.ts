import { TimeToTwelveFormatPipe } from './time-to-twelve-format.pipe';

describe('TimeToTwelveFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new TimeToTwelveFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
