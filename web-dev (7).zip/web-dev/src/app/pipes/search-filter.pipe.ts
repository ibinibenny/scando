import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchFilter'
})
export class SearchFilterPipe implements PipeTransform {

  transform(value: any[], searchProperty: string, search: string): any[] {
    if (value && searchProperty && search) {
      return value.filter(single => single[searchProperty].toLowerCase().includes(search.toLowerCase()));
    } else {
      return value;
    }
  }

}
