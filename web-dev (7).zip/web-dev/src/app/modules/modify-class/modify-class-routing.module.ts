import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateClassComponent } from './create-class/create-class.component';

const routes: Routes = [
  {
    path:'create-class/:first',
    component: CreateClassComponent
  },
  {
    path: 'edit/:id/:mode',
    component: CreateClassComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ModifyClassRoutingModule { }
