import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClassTimePickerComponent } from './class-time-picker.component';

describe('ClassTimePickerComponent', () => {
  let component: ClassTimePickerComponent;
  let fixture: ComponentFixture<ClassTimePickerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClassTimePickerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClassTimePickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
