import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NgbRatingConfig, NgbModalRef, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-class-time-picker',
  templateUrl: './class-time-picker.component.html',
  styleUrls: ['./class-time-picker.component.css']
})
export class ClassTimePickerComponent implements OnInit {

  ngbModalRef: NgbModalRef;
  @Input() start!: string;
  @Input() end!: string;
  @Output() startTimeChanged = new EventEmitter();
  @Output() endTimeChanged = new EventEmitter();

  constructor(
    private modalService: NgbModal,
  ) { }

  ngOnInit(): void {
  }

  public startChanged(time: string) {
    this.start = this.twelveToTwentyFour(time);
    this.startTimeChanged.emit(this.twelveToTwentyFour(time));
  }

  public endChanged(time: string) {
    this.end = this.twelveToTwentyFour(time);
    this.endTimeChanged.emit(this.twelveToTwentyFour(time));
  }

  public twelveToTwentyFour(time: string) {
    const hourMatch = time.match(/^(\d+)/);
    const minuteMatch = time.match(/:(\d+)/);
    const amMatch = time.match(/\s(.*)$/);
    var hours = Number(hourMatch?hourMatch[1]:0);
    var minutes = Number(minuteMatch?minuteMatch[1]:0);
    var AMPM = amMatch?amMatch[1]:'AM';
    if (AMPM == "PM" && hours < 12) hours = hours + 12;
    if (AMPM == "AM" && hours == 12) hours = hours - 12;
    var sHours = hours.toString();
    var sMinutes = minutes.toString();
    if (hours < 10) sHours = "0" + sHours;
    if (minutes < 10) sMinutes = "0" + sMinutes;
    return `${sHours}:${sMinutes}`;
  }
  opendeleteModal(content) {
    this.ngbModalRef = this.modalService.open(content, { centered: true });
  }

}
