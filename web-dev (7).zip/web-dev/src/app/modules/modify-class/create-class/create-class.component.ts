import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DataService } from 'src/app/services/data.service';
import { Constants } from 'src/app/constants/constants';
import { ToastrService } from 'ngx-toastr';
import { StorageService } from 'src/app/services/storage.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute, Router } from '@angular/router';
import { SpecificClassDetailsData } from 'src/app/interfaces/specific-class-details-data';

@Component({
  selector: 'app-create-class',
  templateUrl: './create-class.component.html',
  styleUrls: ['./create-class.component.css']
})
export class CreateClassComponent implements OnInit {

  createClassForm = this.fb.group({
    classType: [null, [Validators.required]],
    className: ['', [Validators.required]],
    coreSubjects: ['', [Validators.required]],
    timetableEnabled: [false],
    monday: [false],
    mondayStart: ['9:00'],
    mondayEnd: ['10:00'],
    tuesday: [false],
    tuesdayStart: ['9:00'],
    tuesdayEnd: ['10:00'],
    wednesday: [false],
    wednesdayStart: ['9:00'],
    wednesdayEnd: ['10:00'],
    thursday: [false],
    thursdayStart: ['9:00'],
    thursdayEnd: ['10:00'],
    friday: [false],
    fridayStart: ['9:00'],
    fridayEnd: ['10:00'],
    saturday: [false],
    saturdayStart: ['9:00'],
    saturdayEnd: ['10:00'],
    sunday: [false],
    sundayStart: ['9:00'],
    sundayEnd: ['10:00'],
  });
  username!: string;
  specificClassDetails!: SpecificClassDetailsData;
  mode!: string|null; //0 = show only timetable, 1 = show both section
  isFirst!: boolean;

  constructor(
    private fb: FormBuilder,
    private dataService: DataService,
    private toastr: ToastrService,
    private storageService: StorageService,
    private modalService: NgbModal,
    private route: ActivatedRoute,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.username = this.storageService.getSessionStorage(Constants.STRINGS.USERNAME);
    this.route.paramMap.subscribe(res => {
      const id = res.get('id');
      if (id) {
        this.getExistingClass(id);
      };
      this.mode = res.get('mode');
      if (this.mode === '0') {
        this.createClassForm.patchValue({timetableEnabled: true});
      }
      const first = res.get('first');
      if (first) {
        this.isFirst = (first === '1');
      }
    });
  }

  public getExistingClass(classId: string) {
    this.dataService.parseApiCall(
      `${Constants.URL.GET_CLASS_SPECIFIC_DETAILS}?classId=${classId}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success && res.data) {
        this.specificClassDetails = res.data[0];
        this.createClassForm.patchValue({
          classType: this.specificClassDetails.classType,
          className: this.specificClassDetails.className,
          coreSubjects: this.specificClassDetails.subjectName,
          timetableEnabled: this.specificClassDetails.isScheduled==1
        });
        if (this.mode === '0') {
          this.createClassForm.patchValue({timetableEnabled: true});
        }
        this.specificClassDetails.timeTable.forEach(element => {
          switch (element.day) {
            case '01':
              this.createClassForm.patchValue({
                monday: true,
                mondayStart: `${element.start.hour}:${element.start.min}`,
                mondayEnd: `${element.end.hour}:${element.end.min}`,
              });
              break;

            case '02':
              this.createClassForm.patchValue({
                tuesday: true,
                tuesdayStart: `${element.start.hour}:${element.start.min}`,
                tuesdayEnd: `${element.end.hour}:${element.end.min}`,
              });
              break;

            case '03':
              this.createClassForm.patchValue({
                wednesday: true,
                wednesdayStart: `${element.start.hour}:${element.start.min}`,
                wednesdayEnd: `${element.end.hour}:${element.end.min}`,
              });
              break;

            case '04':
              this.createClassForm.patchValue({
                thursday: true,
                thursdayStart: `${element.start.hour}:${element.start.min}`,
                thursdayEnd: `${element.end.hour}:${element.end.min}`,
              });
              break;

            case '05':
              this.createClassForm.patchValue({
                friday: true,
                fridayStart: `${element.start.hour}:${element.start.min}`,
                fridayEnd: `${element.end.hour}:${element.end.min}`,
              });
              break;

            case '06':
              this.createClassForm.patchValue({
                saturday: true,
                saturdayStart: `${element.start.hour}:${element.start.min}`,
                saturdayEnd: `${element.end.hour}:${element.end.min}`,
              });
              break;

            case '07':
              this.createClassForm.patchValue({
                sunday: true,
                sundayStart: `${element.start.hour}:${element.start.min}`,
                sundayEnd: `${element.end.hour}:${element.end.min}`,
              });
              break;

            default:
              break;
          }
        });
      }
    });
  }

  public setClassType(type: number) {
    this.createClassForm.patchValue({classType: type});
  }

  public submit(successModal: any) {
    if (this.createClassForm.valid) {
      const data = {
        "classType": this.createClassForm.value.classType,
        "className": this.createClassForm.value.className,
        "subjectName": this.createClassForm.value.coreSubjects,
        "timetableEnabled": this.createClassForm.value.timetableEnabled,
        "timeTable": this.getTimetableArray(),
        "repeatEnabled": true
      };
      if (this.specificClassDetails) {
        // Edit
        this.dataService.parseApiCall(
          `${Constants.URL.UPDATE_CLASSROOM}/${this.specificClassDetails.classId}`,
          'PUT',
          data,
          this.dataService.getTokenHeader()
        ).subscribe(res => {
          if (res.success) {
            this.createClassForm.reset();
            this.toastr.success('Classroom edited successfully');
            this.router.navigate(['/teacher/manage-class']);
          } else {
            this.toastr.error(res.message);
          }
        });
      } else {
        // Create
        this.dataService.parseApiCall(
          Constants.URL.CREATE_CLASS_ROOM,
          'POST',
          data,
          this.dataService.getTokenHeader()
        ).subscribe(res => {
          if (res.success) {
            this.modalService.open(successModal).result.then((result) => {}, (reason) => {});
            this.createClassForm.reset();
          } else {
            this.toastr.error(res.message);
          }
        });
      }
    } else {
      this.toastr.error('Enter all required fields');
    }
  }

  public getTimetableArray() {
    if (this.createClassForm.value.timetableEnabled) {
      const data = [];
      if (this.createClassForm.value.monday) {
        data.push({
          "end": {
            "hour": Number(this.createClassForm.value.mondayEnd.split(':')[0]),
            "min": Number(this.createClassForm.value.mondayEnd.split(':')[1])
          },
          "start": {
            "hour": Number(this.createClassForm.value.mondayStart.split(':')[0]),
            "min": Number(this.createClassForm.value.mondayStart.split(':')[1])
          },
          "day": "01"
        })
      };
      if (this.createClassForm.value.tuesday) {
        data.push({
          "end": {
            "hour": Number(this.createClassForm.value.tuesdayEnd.split(':')[0]),
            "min": Number(this.createClassForm.value.tuesdayEnd.split(':')[1])
          },
          "start": {
            "hour": Number(this.createClassForm.value.tuesdayStart.split(':')[0]),
            "min": Number(this.createClassForm.value.tuesdayStart.split(':')[1])
          },
          "day": "02"
        })
      };
      if (this.createClassForm.value.wednesday) {
        data.push({
          "end": {
            "hour": Number(this.createClassForm.value.wednesdayEnd.split(':')[0]),
            "min": Number(this.createClassForm.value.wednesdayEnd.split(':')[1])
          },
          "start": {
            "hour": Number(this.createClassForm.value.wednesdayStart.split(':')[0]),
            "min": Number(this.createClassForm.value.wednesdayStart.split(':')[1])
          },
          "day": "03"
        })
      };
      if (this.createClassForm.value.thursday) {
        data.push({
          "end": {
            "hour": Number(this.createClassForm.value.thursdayEnd.split(':')[0]),
            "min": Number(this.createClassForm.value.thursdayEnd.split(':')[1])
          },
          "start": {
            "hour": Number(this.createClassForm.value.thursdayStart.split(':')[0]),
            "min": Number(this.createClassForm.value.thursdayStart.split(':')[1])
          },
          "day": "04"
        })
      };
      if (this.createClassForm.value.friday) {
        data.push({
          "end": {
            "hour": Number(this.createClassForm.value.fridayEnd.split(':')[0]),
            "min": Number(this.createClassForm.value.fridayEnd.split(':')[1])
          },
          "start": {
            "hour": Number(this.createClassForm.value.fridayStart.split(':')[0]),
            "min": Number(this.createClassForm.value.fridayStart.split(':')[1])
          },
          "day": "05"
        })
      };
      if (this.createClassForm.value.saturday) {
        data.push({
          "end": {
            "hour": Number(this.createClassForm.value.saturdayEnd.split(':')[0]),
            "min": Number(this.createClassForm.value.saturdayEnd.split(':')[1])
          },
          "start": {
            "hour": Number(this.createClassForm.value.saturdayStart.split(':')[0]),
            "min": Number(this.createClassForm.value.saturdayStart.split(':')[1])
          },
          "day": "06"
        })
      };
      if (this.createClassForm.value.sunday) {
        data.push({
          "end": {
            "hour": Number(this.createClassForm.value.sundayEnd.split(':')[0]),
            "min": Number(this.createClassForm.value.sundayEnd.split(':')[1])
          },
          "start": {
            "hour": Number(this.createClassForm.value.sundayStart.split(':')[0]),
            "min": Number(this.createClassForm.value.sundayStart.split(':')[1])
          },
          "day": "07"
        })
      };
      return data;
    } else {
      return [];
    }
  }

  public patchTime(isStart: boolean, type: number, time: string) {
    if (isStart) {
      switch (type) {
        case 1:
          this.createClassForm.patchValue({ mondayStart: time });
          break;

        case 2:
          this.createClassForm.patchValue({ tuesdayStart: time });
          break;

        case 3:
          this.createClassForm.patchValue({ wednesdayStart: time });
          break;

        case 4:
          this.createClassForm.patchValue({ thursdayStart: time });
          break;

        case 5:
          this.createClassForm.patchValue({ fridayStart: time });
          break;

        case 6:
          this.createClassForm.patchValue({ saturdayStart: time });
          break;

        case 7:
          this.createClassForm.patchValue({ sundayStart: time });
          break;

        default:
          break;
      }
    } else {
      switch (type) {
        case 1:
          this.createClassForm.patchValue({ mondayEnd: time });
          break;

        case 2:
          this.createClassForm.patchValue({ tuesdayEnd: time });
          break;

        case 3:
          this.createClassForm.patchValue({ wednesdayEnd: time });
          break;

        case 4:
          this.createClassForm.patchValue({ thursdayEnd: time });
          break;

        case 5:
          this.createClassForm.patchValue({ fridayEnd: time });
          break;

        case 6:
          this.createClassForm.patchValue({ saturdayEnd: time });
          break;

        case 7:
          this.createClassForm.patchValue({ sundayEnd: time });
          break;

        default:
          break;
      }
    }
  }

}
