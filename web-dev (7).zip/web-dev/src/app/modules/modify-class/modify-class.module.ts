import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ModifyClassRoutingModule } from './modify-class-routing.module';
import { CreateClassComponent } from './create-class/create-class.component';
import { ClassTimePickerComponent } from './class-time-picker/class-time-picker.component';
import { GlobalModule } from '../global/global.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';


@NgModule({
  declarations: [
    CreateClassComponent,
    ClassTimePickerComponent
  ],
  imports: [
    CommonModule,
    ModifyClassRoutingModule,
    GlobalModule,
    FormsModule,
    ReactiveFormsModule,
    NgxMaterialTimepickerModule,
  ]
})
export class ModifyClassModule { }
