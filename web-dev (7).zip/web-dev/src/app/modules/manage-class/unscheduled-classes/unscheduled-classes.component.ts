import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AllClassDetailsData } from 'src/app/interfaces/all-class-details-data';
import { Constants } from 'src/app/constants/constants';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-unscheduled-classes',
  templateUrl: './unscheduled-classes.component.html',
  styleUrls: ['./unscheduled-classes.component.css'],
})
export class UnscheduledClassesComponent implements OnInit {
  @Input() classes: AllClassDetailsData[] = [];
  @Output() deleteClass: EventEmitter<AllClassDetailsData> = new EventEmitter();
  @Input() search!: string;

  constructor(private dataService: DataService) {}

  ngOnInit(): void {}

  public toDeleteClass(classToDelete: AllClassDetailsData){
    this.deleteClass.emit(classToDelete);
  }
}
