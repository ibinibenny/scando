import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnscheduledClassesComponent } from './unscheduled-classes.component';

describe('UnscheduledClassesComponent', () => {
  let component: UnscheduledClassesComponent;
  let fixture: ComponentFixture<UnscheduledClassesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UnscheduledClassesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnscheduledClassesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
