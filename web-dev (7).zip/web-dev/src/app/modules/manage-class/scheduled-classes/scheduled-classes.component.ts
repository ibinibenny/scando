import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AllClassDetailsData } from 'src/app/interfaces/all-class-details-data';
import { DataService } from 'src/app/services/data.service';
import { Constants } from 'src/app/constants/constants';
@Component({
  selector: 'app-scheduled-classes',
  templateUrl: './scheduled-classes.component.html',
  styleUrls: ['./scheduled-classes.component.css'],
})
export class ScheduledClassesComponent implements OnInit {

  @Input() classes: AllClassDetailsData[] = [];
  @Output() deleteClass: EventEmitter<AllClassDetailsData> = new EventEmitter();
  @Input() search!: string;

  constructor(private dataService: DataService) {}

  ngOnInit(): void {}

  public toDeleteClass(classToDelete: AllClassDetailsData){
    this.deleteClass.emit(classToDelete);
  }
  
}
