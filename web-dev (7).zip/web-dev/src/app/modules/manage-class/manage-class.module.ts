import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ManageClassRoutingModule } from './manage-class-routing.module';
import { ManageClassComponent } from './manage-class/manage-class.component';
import { ClassDetailedComponent } from './class-detailed/class-detailed.component';
import { ScheduledClassesComponent } from './scheduled-classes/scheduled-classes.component';
import { UnscheduledClassesComponent } from './unscheduled-classes/unscheduled-classes.component';
import { TeacherEnrolmentComponent } from './teacher-enrolment/teacher-enrolment.component';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { GlobalModule } from '../global/global.module';
import { TeacherClassSettingsComponent } from './teacher-class-settings/teacher-class-settings.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';


@NgModule({
  declarations: [
    ManageClassComponent,
    ClassDetailedComponent,
    ScheduledClassesComponent,
    UnscheduledClassesComponent,
    TeacherEnrolmentComponent,
    TeacherClassSettingsComponent,
  ],
  imports: [
    CommonModule,
    ManageClassRoutingModule,
    NgbDropdownModule,
    GlobalModule,
    ReactiveFormsModule,
    NgxMaterialTimepickerModule,
    FormsModule,
  ]
})
export class ManageClassModule { }
