import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Constants } from 'src/app/constants/constants';
import { AllClassDetailsData } from 'src/app/interfaces/all-class-details-data';
import { DataService } from 'src/app/services/data.service';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-manage-class',
  templateUrl: './manage-class.component.html',
  styleUrls: ['./manage-class.component.css']
})
export class ManageClassComponent implements OnInit {

  selectedTab = 1;
  scheduledClasses: AllClassDetailsData[] = [];
  unScheduledClasses: AllClassDetailsData[] = [];
  search!: string;

  constructor(
    private dataService: DataService,
    private storageService: StorageService,
    private toastr: ToastrService,
  ) { }

  ngOnInit(): void {
    this.getScheduledClasses();
    this.getUnScheduledClasses();
  }

  public getScheduledClasses() {
    const userId = this.storageService.getSessionStorage(Constants.STRINGS.USER_ID);
    this.dataService.parseApiCall(
      `${Constants.URL.GET_ALL_CLASS_DETAILS_TEACHER}?userId=${userId}&isScheduled=1`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.scheduledClasses = res.data;
      }
    });
  }

  public getUnScheduledClasses() {
    const userId = this.storageService.getSessionStorage(Constants.STRINGS.USER_ID);
    this.dataService.parseApiCall(
      `${Constants.URL.GET_ALL_CLASS_DETAILS_TEACHER}?userId=${userId}&isScheduled=0`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.unScheduledClasses = res.data;
      }
    });
  }

  public toDeleteClass(classToDelete: AllClassDetailsData) {
    const data = {
      classId: classToDelete.classId,
    };
    this.dataService
      .parseApiCall(
        Constants.URL.DELETE_CLASS_ROOM,
        'DELETE',
        data,
        this.dataService.getTokenHeader()
      )
      .subscribe((res) => {
        if (res.success && res.data) {
          console.log('class deleted successfully.');
          this.toastr.success('Classroom deleted successfully');
          this.getScheduledClasses();
          this.getUnScheduledClasses();
        }
      });
  }

}
