import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ClassDetailedComponent } from './class-detailed/class-detailed.component';
import { ManageClassComponent } from './manage-class/manage-class.component';
import { TeacherEnrolmentComponent } from './teacher-enrolment/teacher-enrolment.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: ManageClassComponent
  },
  {
    path: 'class/:id/enrolment',
    component: TeacherEnrolmentComponent
  },
  {
    path: 'class/:id',
    component: ClassDetailedComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManageClassRoutingModule { }
