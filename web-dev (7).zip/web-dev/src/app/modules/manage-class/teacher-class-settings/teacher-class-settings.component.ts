import { Component, Input, OnInit } from '@angular/core';
import { SpecificClassDetailsData } from 'src/app/interfaces/specific-class-details-data';

@Component({
  selector: 'app-teacher-class-settings',
  templateUrl: './teacher-class-settings.component.html',
  styleUrls: ['./teacher-class-settings.component.css']
})
export class TeacherClassSettingsComponent implements OnInit {

  @Input() showCreateClass = true;
  @Input() classData: SpecificClassDetailsData;

  constructor() { }

  ngOnInit(): void {
  }

}
