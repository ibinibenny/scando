import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeacherClassSettingsComponent } from './teacher-class-settings.component';

describe('TeacherClassSettingsComponent', () => {
  let component: TeacherClassSettingsComponent;
  let fixture: ComponentFixture<TeacherClassSettingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TeacherClassSettingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TeacherClassSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
