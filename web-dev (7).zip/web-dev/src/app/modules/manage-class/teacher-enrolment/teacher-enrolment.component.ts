import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ClipboardService } from 'ngx-clipboard';
import { ToastrService } from 'ngx-toastr';
import { Constants } from 'src/app/constants/constants';
import { ApprovalListData } from 'src/app/interfaces/approval-list-data';
import { DataService } from 'src/app/services/data.service';
import { NgbRatingConfig, NgbModalRef, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-teacher-enrolment',
  templateUrl: './teacher-enrolment.component.html',
  styleUrls: ['./teacher-enrolment.component.css']
})
export class TeacherEnrolmentComponent implements OnInit {

  studentsToVerify: ApprovalListData[] = [];
  studentsVerified: ApprovalListData[] = [];
  classId!: string|null;
  search!: string;
  ngbModalRef: NgbModalRef;

  constructor(
    private dataService: DataService,
    private activatedRoute: ActivatedRoute,
    private clipboardService: ClipboardService,
    private toastr: ToastrService,
    private modalService: NgbModal,
  ) { }

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe((params) => {
      this.classId = params.get('id');
      if (this.classId) {
        this.getApprovalList(this.classId);
      }
    });
  }

  public getApprovalList(classId: string) {
    this.dataService.parseApiCall(
      `${Constants.URL.APPROVAL_LIST}?classId=${classId}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        try {
          this.studentsToVerify = res.data.list.filter((single: ApprovalListData) => single.enrollStatus === 0);
          this.studentsVerified = res.data.list.filter((single: ApprovalListData) => single.enrollStatus === 1);
        } catch (error) {
          
        }
      }
    });
  }

  public verifyEnrolment(dataToVerify: ApprovalListData) {
    const data = {
      classId: dataToVerify.classId,
      studentId: dataToVerify.studentId
    };
    this.dataService.parseApiCall(
      Constants.URL.APPROVE,
      'POST',
      data,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.studentsToVerify.splice(this.studentsToVerify.indexOf(dataToVerify), 1);
        this.studentsVerified.push(dataToVerify);
      }
    })
  }

  public unEnrol(dataToUnEnrol: ApprovalListData) {
    const data = {
      classId: dataToUnEnrol.classId,
      studentId: dataToUnEnrol.studentId
    };
    this.dataService.parseApiCall(
      Constants.URL.TEACHER_UN_ENROLL,
      'POST',
      data,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.studentsVerified.splice(this.studentsVerified.indexOf(dataToUnEnrol), 1);
      }
    })
  }

  public copyClassId() {
    this.clipboardService.copy(String(this.classId));
    this.toastr.success('Class ID copied to clipboard. Please share it with students.');
  }

  public enrollAll() {
    this.studentsToVerify.forEach(element => {
      this.verifyEnrolment(element);
    });
  }
  openCreateModal(content) {
    this.ngbModalRef = this.modalService.open(content, { centered: true });
  }
}
