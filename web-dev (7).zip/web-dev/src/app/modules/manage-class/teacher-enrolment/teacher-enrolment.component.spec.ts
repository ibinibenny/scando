import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeacherEnrolmentComponent } from './teacher-enrolment.component';

describe('TeacherEnrolmentComponent', () => {
  let component: TeacherEnrolmentComponent;
  let fixture: ComponentFixture<TeacherEnrolmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TeacherEnrolmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TeacherEnrolmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
