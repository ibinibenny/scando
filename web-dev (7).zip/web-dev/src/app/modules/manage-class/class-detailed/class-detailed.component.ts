import { Component, OnInit } from '@angular/core';
import { Constants } from 'src/app/constants/constants';
import { DataService } from 'src/app/services/data.service';
import { StorageService } from 'src/app/services/storage.service';
import { ActivatedRoute } from '@angular/router';
import { SpecificClassDetailsData } from 'src/app/interfaces/specific-class-details-data';
import { ClipboardService } from 'ngx-clipboard';
import { ApprovalListData } from 'src/app/interfaces/approval-list-data';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-class-detailed',
  templateUrl: './class-detailed.component.html',
  styleUrls: ['./class-detailed.component.css'],
})
export class ClassDetailedComponent implements OnInit {

  specificClassDetails!: SpecificClassDetailsData;
  enrolledCount = 0;
  username!: string;

  constructor(
    private dataService: DataService,
    private storageService: StorageService,
    private activatedRoute: ActivatedRoute,
    private clipboardService: ClipboardService,
    private toastr: ToastrService,
  ) {}

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe((params) => {
      const classId = params.get('id');
      if (classId) {
        this.getClassDetails(classId);
        this.getApprovalList(classId);
      }
    });
    this.username = this.storageService.getSessionStorage(Constants.STRINGS.USERNAME);
  }

  public getClassDetails(classId: string) {
    this.dataService.parseApiCall(
      `${Constants.URL.GET_CLASS_SPECIFIC_DETAILS}?classId=${classId}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success && res.data) {
        this.specificClassDetails = res.data[0];
      }
    });
  }

  public copyClassId() {
    this.clipboardService.copy(String(this.specificClassDetails.classId));
    this.toastr.success('Classroom ID copied to clipboard');
  }

  public getApprovalList(classId: string) {
    this.dataService.parseApiCall(
      `${Constants.URL.APPROVAL_LIST}?classId=${classId}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        try {
          this.enrolledCount = res.data.list.filter((single: ApprovalListData) => single.enrollStatus === 1).length;
        } catch (error) {
          
        }
      }
    });
  }
  
}
