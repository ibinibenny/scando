import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClassDetailedComponent } from './class-detailed.component';

describe('ClassDetailedComponent', () => {
  let component: ClassDetailedComponent;
  let fixture: ComponentFixture<ClassDetailedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClassDetailedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClassDetailedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
