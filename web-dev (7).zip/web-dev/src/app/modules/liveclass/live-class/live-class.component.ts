import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';

import AgoraRTC, { IAgoraRTCRemoteUser, ICameraVideoTrack, ILocalVideoTrack, IMicrophoneAudioTrack, IRemoteVideoTrack } from "agora-rtc-sdk-ng";
import { Constants } from 'src/app/constants/constants';
import { DataService } from 'src/app/services/data.service';
import { StorageService } from 'src/app/services/storage.service';
import { IAgoraRTCClient } from 'agora-rtc-sdk-ng';
import { ActivatedRoute, Router } from '@angular/router';
import { AREAS } from 'agora-rtc-sdk';
import AgoraRTM, { RtmChannel, RtmClient } from 'agora-rtm-sdk';
import { LiveUserData } from 'src/app/interfaces/live-user-data';

interface RtcData {
  client: IAgoraRTCClient|null,
  // For the local audio and video tracks.
  localAudioTrack: IMicrophoneAudioTrack|null,
  localVideoTrack: ICameraVideoTrack|null,
}

@Component({
  selector: 'app-live-class',
  templateUrl: './live-class.component.html',
  styleUrls: ['./live-class.component.css']
})
export class LiveClassComponent implements OnInit {

  constructor(
    private dataService: DataService,
    private storageService: StorageService,
    private route: ActivatedRoute,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(res => {
      const id = res.get('id');
      const className = res.get('className');
      if (id) {
        this.getMessagingToken(id, className);
      }
    });
  }

  public getMessagingToken(classId: string, className: string) {
    const data = {
      "appId": Constants.AGORA.APP_ID,
      "appCertificate": Constants.AGORA.APP_CERTIFICATE,
      "userId": this.storageService.getSessionStorage(Constants.STRINGS.USER_ID),
      "channelName": classId
    }
    this.dataService.parseApiCall(
      Constants.URL.GET_RTM_TOKEN,
      'POST',
      data,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        window.AgoraEduSDK.config({
          appId: Constants.AGORA.APP_ID,
          region: "AP",
        });
        const launchOption = {
          userUuid: String(this.storageService.getSessionStorage(Constants.STRINGS.USER_ID)),
          userName: this.storageService.getSessionStorage(Constants.STRINGS.USERNAME),
          roomUuid: classId,
          roleType: this.storageService.getSessionStorage(Constants.STRINGS.USER_TYPE)+1,
          roomType: 4,
          roomName: className,
          listener: (evt) => {
            console.log("evt", evt)
          },
          pretest: false,
          rtmToken: res.data.token,
          language: 'en',
          startTime: Date.now(),
          duration: 300 * 60,
          courseWareList: []
        };
        console.log(launchOption);
        window.AgoraEduSDK.launch(document.getElementById('videowrap'), {
          ...launchOption,
          listener: (evt: any, type) => {
            if (evt === 1) {
              // class started
              this.classInitiateApi(data.userId, data.channelName);
            } else if (evt === 2) {
              // Class ended
              this.classEndedApi(data.userId, data.channelName);
              if (this.storageService.getSessionStorage(Constants.STRINGS.USER_TYPE) === 0) {
                this.router.navigate(['/teacher/manage-class/class', classId]);
              } else {
                this.router.navigate(['/student/class', classId]);
              }
            }
          },
        });
      }
    });
  }

  public classInitiateApi(userId: string, classId: string) {
    if (this.storageService.getSessionStorage(Constants.STRINGS.USER_TYPE) === 0) {
      const data = {
        classId: classId,
        userId: userId
      };
      this.dataService.parseApiCall(
        Constants.URL.TEACHER_CLASS_STARTED,
        'POST',
        data,
        this.dataService.getTokenHeader()
      ).subscribe(res => {

      });
    } else {
      const data = {
        classId: classId
      };
      this.dataService.parseApiCall(
        Constants.URL.STUDENT_CLASS_STARTED,
        'POST',
        data,
        this.dataService.getTokenHeader()
      ).subscribe(res => {

      });
    }
  }

  public classEndedApi(userId: string, classId: string) {
    if (this.storageService.getSessionStorage(Constants.STRINGS.USER_TYPE) === 0) {
      const data = {
        classId: classId,
        userId: userId
      };
      this.dataService.parseApiCall(
        Constants.URL.TEACHER_CLASS_ENDED,
        'POST',
        data,
        this.dataService.getTokenHeader()
      ).subscribe(res => {

      });
    } else {
      const data = {
        classId: classId
      };
      this.dataService.parseApiCall(
        Constants.URL.STUDENT_CLASS_ENDED,
        'POST',
        data,
        this.dataService.getTokenHeader()
      ).subscribe(res => {

      });
    }
  }

}