import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GoLiveComponent } from './go-live/go-live.component';
import { LiveClassComponent } from './live-class/live-class.component';
import { LiveWithImgComponent } from './live-with-img/live-with-img.component';
import { StudViewComponent } from './stud-view/stud-view.component';
const routes: Routes = [
  {
    path: 'go-live',
    component: GoLiveComponent
  },
  {
    path: 'live-with-img',
    component: LiveWithImgComponent
  },
  {
    path: 'stud-view',
    component: StudViewComponent
  },
  {
    path: ':id/:className',
    component: LiveClassComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LiveclassRoutingModule { }
