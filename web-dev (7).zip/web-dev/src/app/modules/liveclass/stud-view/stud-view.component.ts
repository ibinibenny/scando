import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stud-view',
  templateUrl: './stud-view.component.html',
  styleUrls: ['./stud-view.component.css']
})
export class StudViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
