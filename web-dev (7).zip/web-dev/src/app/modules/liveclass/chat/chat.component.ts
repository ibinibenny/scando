import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { RtmChannel } from 'agora-rtm-sdk';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent implements OnChanges {

  @Input() messages: {username: string, message: string}[] = [];

  constructor() { }

  ngOnChanges(changes: SimpleChanges): void {
    
  }

}
