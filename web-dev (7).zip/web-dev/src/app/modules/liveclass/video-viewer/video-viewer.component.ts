import { Component, ElementRef, Input, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { ICameraVideoTrack, ILocalVideoTrack, IRemoteVideoTrack } from 'agora-rtc-sdk-ng';

@Component({
  selector: 'app-video-viewer',
  templateUrl: './video-viewer.component.html',
  styleUrls: ['./video-viewer.component.css']
})
export class VideoViewerComponent implements OnChanges {

  @Input() videoSrc: ICameraVideoTrack|IRemoteVideoTrack|ILocalVideoTrack;
  @ViewChild('videowrap') videowrap!: ElementRef;

  constructor() { }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.videoSrc) {
      this.videoSrc.play(this.videowrap.nativeElement);
    }
  }

}
