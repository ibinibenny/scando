import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LiveclassRoutingModule } from './liveclass-routing.module';
import { LiveClassComponent } from './live-class/live-class.component';
import { GoLiveComponent } from './go-live/go-live.component';
import { StudViewComponent } from './stud-view/stud-view.component';
import { LiveWithImgComponent } from './live-with-img/live-with-img.component';
import { StudentComponent } from './student/student.component';
import { WhiteBoardComponent } from './white-board/white-board.component';
import { VideoViewerComponent } from './video-viewer/video-viewer.component';
import { GlobalModule } from '../global/global.module';
import { NgbPopoverModule } from '@ng-bootstrap/ng-bootstrap';
import { ChatComponent } from './chat/chat.component';


@NgModule({
  declarations: [
    LiveClassComponent,
    GoLiveComponent,
    StudViewComponent,
    LiveWithImgComponent,
    StudentComponent,
    WhiteBoardComponent,
    VideoViewerComponent,
    ChatComponent
  ],
  imports: [
    CommonModule,
    LiveclassRoutingModule,
    GlobalModule,
    NgbPopoverModule,
  ]
})
export class LiveclassModule { }
