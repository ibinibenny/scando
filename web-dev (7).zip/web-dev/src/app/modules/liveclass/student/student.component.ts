import { Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { IAgoraRTCRemoteUser, IRemoteAudioTrack, IRemoteVideoTrack } from 'agora-rtc-sdk-ng';
import { RtmChannel, RtmClient } from 'agora-rtm-sdk';
import { LiveUserData } from 'src/app/interfaces/live-user-data';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnChanges {
  @Input() audio!: IRemoteAudioTrack;
  @Input() video!: IRemoteVideoTrack;
  @Input() rtmClient: RtmClient;
  @Input() student: IAgoraRTCRemoteUser;
  name = 'U';
  role: string;
  @Output() nameFetched: EventEmitter<string> = new EventEmitter();
  @Input() channel: RtmChannel;

  constructor() { }

  ngOnChanges(changes: SimpleChanges): void {
    this.audio?.play();
    if (this.student && this.rtmClient) {
      setTimeout(() => {
        try {
          this.rtmClient.getUserAttributesByKeys(String(this.student.uid), ['name']).then(res => {
            if (res.name) {
              this.nameFetched.emit(res.name);
              this.name = res.name.substring(0, 2).toUpperCase();
            }
          });
        } catch (error) {
          
        }
      }, 5000);
    }
    if (this.student&&this.channel) {
      this.channel.on('ChannelMessage', async (message, memberId) => {
        try {
          console.log('here');
          const json = JSON.parse(message.text);
          if (json.cmd === 20) {
            json.data.onlineUsers.forEach(element => {
              if (Number(element.streamUuid) === this.student.uid) {
                this.nameFetched.emit(element.userName);
                this.name = element.userName.substring(0, 2).toUpperCase();
              }
            });
            json.data.offlineUsers.forEach(element => {
              if (Number(element.streamUuid) === this.student.uid) {
                this.nameFetched.emit(element.userName);
                this.name = element.userName.substring(0, 2).toUpperCase();
              }
            });
          } else if (json.cmd === 3) {

          }
        } catch (error) {
          
        }
      });
    }
  }

}
