import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GoLiveRoutingModule } from './go-live-routing.module';
import { GoLiveComponent } from './go-live/go-live.component';


@NgModule({
  declarations: [
    GoLiveComponent
  ],
  imports: [
    CommonModule,
    GoLiveRoutingModule
  ]
})
export class GoLiveModule { }
