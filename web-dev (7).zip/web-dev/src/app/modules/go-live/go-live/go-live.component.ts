import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-go-live',
  templateUrl: './go-live.component.html',
  styleUrls: ['./go-live.component.css']
})
export class GoLiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
