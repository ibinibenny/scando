import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Constants } from 'src/app/constants/constants';
import { SpecificClassDetailsData } from 'src/app/interfaces/specific-class-details-data';
import { DataService } from 'src/app/services/data.service';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-specific-class',
  templateUrl: './specific-class.component.html',
  styleUrls: ['./specific-class.component.css'],
})
export class SpecificClassComponent implements OnInit {
  public specificClassDetails!: SpecificClassDetailsData;
  username!: string;

  constructor(
    private dataService: DataService,
    private activatedRoute: ActivatedRoute,
    private storageService: StorageService
  ) {}

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe((params) => {
      const classId = params.get('id');
      if (classId) {
        this.getClassDetails(classId);
      }
    });
    this.username = this.storageService.getSessionStorage(
      Constants.STRINGS.USERNAME
    );
  }

  public getClassDetails(classId: string) {
    this.dataService
      .parseApiCall(
        `${Constants.URL.GET_STUDENT_CLASS_DETAILS}?classId=${classId}`,
        'GET',
        null,
        this.dataService.getTokenHeader()
      )
      .subscribe((res) => {
        if (res.success && res.data) {
          this.specificClassDetails = res.data[0];
          console.log('specificClassDetails:', this.specificClassDetails);
          for (
            let i = 0;
            i < this.specificClassDetails?.timeTable?.length;
            i++
          ) {
            const startDate = new Date();
            const currentTimeStamp = startDate.getTime();
            // console.log('startDate:', startDate);
            // console.log('currentTimeStamp:', currentTimeStamp);
            const classStartTime = startDate.setHours(
              this.specificClassDetails.timeTable[i]?.start.hour,
              this.specificClassDetails.timeTable[i]?.start.min,
              0,
              0
            );
            const classEndTime = startDate.setHours(
              this.specificClassDetails.timeTable[i]?.end.hour,
              this.specificClassDetails.timeTable[i]?.end.min,
              0,
              0
            );
            if (
              currentTimeStamp > classStartTime &&
              currentTimeStamp < classEndTime
            ) {
              console.log('class is available');
            } else {
              console.log('class not available');
            }
          }
        }
      });
  }
}
