import { Component, OnInit } from '@angular/core';
import { Constants } from 'src/app/constants/constants';
import { EnrolmentPendingData } from 'src/app/interfaces/approval-pending';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-approval-pending',
  templateUrl: './approval-pending.component.html',
  styleUrls: ['./approval-pending.component.css']
})
export class ApprovalPendingComponent implements OnInit {
  pending = true;
  approvalPending: EnrolmentPendingData[];
  constructor(
    private dataService: DataService,
  ) { 

  }

  ngOnInit(): void {
    this.getEnrollLIst();
  }

  public getEnrollLIst() {
    this.dataService.parseApiCall(
      `${Constants.URL.GET_ENROLL_STATUS}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.approvalPending = res.data.list.filter(single => {
          return single.enrollStatus !== 1;
        });
      } else {
        this.approvalPending = [];
      }
    })
  }

}

