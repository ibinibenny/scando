import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApprovalPendingComponent } from './approval-pending/approval-pending.component';
import { EntrolmentRequestComponent } from './entrolment-request/entrolment-request.component';
import { SpecificClassComponent } from './specific-class/specific-class.component';
import { StudentClassComponent } from './student-class/student-class.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: StudentClassComponent
  },
  {
    path: 'enrolment',
    component: EntrolmentRequestComponent
  },
  {
    path: 'pending',
    component: ApprovalPendingComponent
  },
  {
    path: ':id',
    component: SpecificClassComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StudentClassRoutingModule { }
