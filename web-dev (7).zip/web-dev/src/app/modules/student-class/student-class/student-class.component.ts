import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Constants } from 'src/app/constants/constants';
import { AllClassDetailsData } from 'src/app/interfaces/all-class-details-data';
import { DataService } from 'src/app/services/data.service';
import { StorageService } from 'src/app/services/storage.service';
@Component({
  selector: 'app-student-class',
  templateUrl: './student-class.component.html',
  styleUrls: ['./student-class.component.css']
})
export class StudentClassComponent implements OnInit {
  allClasses: AllClassDetailsData[] = [];
  selectedTab = 1;
  closeResult = '';
  scheduledClasses: AllClassDetailsData[] = [];
  unScheduledClasses: AllClassDetailsData[] = [];
  search!: string;
  today = new Date();

  constructor(
    private dataService: DataService,
    private storageService: StorageService
    ) { }

    ngOnInit(): void {
      this.getScheduledClasses();
      this.getUnScheduledClasses();
    }

    public getScheduledClasses() {
      const userId = this.storageService.getSessionStorage(Constants.STRINGS.USER_ID);
      this.dataService.parseApiCall(
        `${Constants.URL.GET_STUDENT_ALL_CLASS_DETAILS}?userId=${userId}&isScheduled=1`,
        'GET',
        null,
        this.dataService.getTokenHeader()
      ).subscribe(res => {
        if (res.success) {
          this.scheduledClasses = res.data.filter((single: AllClassDetailsData) => single.isEnrolled === 1);
          this.scheduledClasses.forEach(single => {
            if (single.feePaymentType === 1) {
              // Monthly
              const date = new Date();
              date.setDate(single.feeCollectionType);
              const timeLine = {
                1: 2,
                2: 5,
                3: 7
              };
              if (single.lastFeePaymentMonth && single.lastFeePaymentMonth === (this.today.getMonth() + 1)) {
                single.isPaymentValid = true;
              } else {
                single.isPaymentValid = false;
              }
            } else {
              single.isPaymentValid = true;
            }
          })
        }
      });
    }

    public getUnScheduledClasses() {
      const userId = this.storageService.getSessionStorage(Constants.STRINGS.USER_ID);
      this.dataService.parseApiCall(
        `${Constants.URL.GET_STUDENT_ALL_CLASS_DETAILS}?userId=${userId}&isScheduled=0`,
        'GET',
        null,
        this.dataService.getTokenHeader()
      ).subscribe(res => {
        if (res.success) {
          this.unScheduledClasses = res.data.filter((single: AllClassDetailsData) => single.isEnrolled === 1);
        }
      });
    }
}
