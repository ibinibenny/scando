import { Component, Input, OnInit } from '@angular/core';
import { Flutterwave, PaymentSuccessResponse } from 'flutterwave-angular-v3';
import { FlutterwaveCheckout, InlinePaymentOptions } from 'flutterwave-angular-v3/src/app/modules/models';
import { Constants } from 'src/app/constants/constants';
import { AllClassDetailsData } from 'src/app/interfaces/all-class-details-data';
import { DataService } from 'src/app/services/data.service';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-scheduled-classes',
  templateUrl: './scheduled-classes.component.html',
  styleUrls: ['./scheduled-classes.component.css']
})
export class ScheduledClassesComponent implements OnInit {

  @Input() classes: AllClassDetailsData[] = [];
  @Input() search!: string;

  constructor() { }

  ngOnInit(): void {
  }

}
