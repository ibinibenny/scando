import { Component, Input, OnInit } from '@angular/core';
import { AllClassDetailsData } from 'src/app/interfaces/all-class-details-data';

@Component({
  selector: 'app-unscheduled-classes',
  templateUrl: './unscheduled-classes.component.html',
  styleUrls: ['./unscheduled-classes.component.css']
})
export class UnscheduledClassesComponent implements OnInit {

  @Input() classes: AllClassDetailsData[] = [];
  @Input() search!: string;

  constructor() { }

  ngOnInit(): void {
  }

}
