import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-class-settings',
  templateUrl: './student-class-settings.component.html',
  styleUrls: ['./student-class-settings.component.css']
})
export class StudentClassSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
