import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentClassSettingsComponent } from './student-class-settings.component';

describe('StudentClassSettingsComponent', () => {
  let component: StudentClassSettingsComponent;
  let fixture: ComponentFixture<StudentClassSettingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentClassSettingsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentClassSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
