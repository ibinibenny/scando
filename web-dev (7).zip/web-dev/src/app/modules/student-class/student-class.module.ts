import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StudentClassRoutingModule } from './student-class-routing.module';
import { StudentClassComponent } from './student-class/student-class.component';
import { EntrolmentRequestComponent } from './entrolment-request/entrolment-request.component';
import { ScheduledClassesComponent } from './scheduled-classes/scheduled-classes.component';
import { UnscheduledClassesComponent } from './unscheduled-classes/unscheduled-classes.component';
import { SpecificClassComponent } from './specific-class/specific-class.component';
import { FormsModule } from '@angular/forms';
import { NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { StudentClassSettingsComponent } from './student-class-settings/student-class-settings.component';
import { GlobalModule } from '../global/global.module';
import { ApprovalPendingComponent } from './approval-pending/approval-pending.component';
import { FlutterwaveModule } from 'flutterwave-angular-v3';


@NgModule({
  declarations: [
    StudentClassComponent,
    EntrolmentRequestComponent,
    ScheduledClassesComponent,
    UnscheduledClassesComponent,
    SpecificClassComponent,
    StudentClassSettingsComponent,
    ApprovalPendingComponent,
  ],
  imports: [
    CommonModule,
    StudentClassRoutingModule,
    FormsModule,
    NgbDropdownModule,
    GlobalModule,
    FlutterwaveModule
  ]
})
export class StudentClassModule { }
