import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EntrolmentRequestComponent } from './entrolment-request.component';

describe('EntrolmentRequestComponent', () => {
  let component: EntrolmentRequestComponent;
  let fixture: ComponentFixture<EntrolmentRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EntrolmentRequestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EntrolmentRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
