import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { Constants } from 'src/app/constants/constants';
import { DataService } from 'src/app/services/data.service';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-entrolment-request',
  templateUrl: './entrolment-request.component.html',
  styleUrls: ['./entrolment-request.component.css'],
})
export class EntrolmentRequestComponent implements OnInit {
  classId!: string;
  username!: string;

  constructor(
    private dataService: DataService,
    private modalService: NgbModal,
    private storageService: StorageService,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    this.username = this.storageService.getSessionStorage(
      Constants.STRINGS.USERNAME
    );
  }

  public enrolClass(modalContent: any) {
    if (this.classId && Number(this.classId)) {
      const data = {
        classId: this.classId,
        studentId: this.storageService.getSessionStorage(
          Constants.STRINGS.USER_ID
        ),
        enrollType: 1,
      };
      this.dataService
        .parseApiCall(
          Constants.URL.ENROLL_CLASS,
          'POST',
          data,
          this.dataService.getTokenHeader()
        )
        .subscribe((res) => {
          if (res.success) {
            this.openModal(modalContent);
          } else {
            this.toastr.error(res.completeResponse.data.message);
            this.classId = '';
          }
        });
    }
  }

  openModal(content: any) {
    this.modalService
      .open(content, {
        ariaLabelledBy: 'modal-basic-title',
        windowClass: 'request-sent-modal',
        centered: true,
      })
      .result.then(
        (result) => {},
        (reason) => {}
      );
  }
}
