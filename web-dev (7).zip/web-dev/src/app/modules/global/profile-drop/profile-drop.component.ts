import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-profile-drop',
  templateUrl: './profile-drop.component.html',
  styleUrls: ['./profile-drop.component.css']
})
export class ProfileDropComponent implements OnInit {

  constructor(
    private router: Router,
    private modalService: NgbModal
  ) { }

  ngOnInit(): void {
  }
  openVerticallyCentered(content) {
    this.modalService.open(content, { windowClass: 'offcanvas-menu' } );
  }
  logout() {
    sessionStorage.clear();
    this.router.navigate(['/']);
  }

}
