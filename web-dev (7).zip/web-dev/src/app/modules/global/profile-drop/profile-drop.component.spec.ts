import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileDropComponent } from './profile-drop.component';

describe('ProfileDropComponent', () => {
  let component: ProfileDropComponent;
  let fixture: ComponentFixture<ProfileDropComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProfileDropComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileDropComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
