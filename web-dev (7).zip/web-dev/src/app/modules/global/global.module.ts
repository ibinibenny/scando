import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ProfileDropComponent } from './profile-drop/profile-drop.component';
import { NgbDropdownModule, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TimeFromTimetablePipe } from 'src/app/pipes/time-from-timetable.pipe';
import { TodayClassTimePipe } from 'src/app/pipes/today-class-time.pipe';
import { SearchFilterPipe } from 'src/app/pipes/search-filter.pipe';
import { ActivityListPipe } from 'src/app/pipes/activity-list.pipe';
import { TimeToTwelveFormatPipe } from 'src/app/pipes/time-to-twelve-format.pipe';
import { GetTeacherPipe } from 'src/app/pipes/get-teacher.pipe';
import { BackButtonDirective } from 'src/app/directives/back-button.directive';



@NgModule({
  declarations: [
    ProfileDropComponent,
    TimeFromTimetablePipe,
    TodayClassTimePipe,
    SearchFilterPipe,
    ActivityListPipe,
    TimeToTwelveFormatPipe,
    GetTeacherPipe,
    BackButtonDirective,
  ],
  imports: [
    CommonModule,
    RouterModule,
    NgbDropdownModule,
    NgbModule
  ],
  exports: [
    ProfileDropComponent,
    TimeFromTimetablePipe,
    TodayClassTimePipe,
    SearchFilterPipe,
    ActivityListPipe,
    TimeToTwelveFormatPipe,
    GetTeacherPipe,
    BackButtonDirective,
  ]
})
export class GlobalModule { }
