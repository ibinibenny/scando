import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Constants } from 'src/app/constants/constants';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-container',
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.css']
})
export class ContainerComponent implements OnInit {

  userName: string;

  constructor(
    private modalService: NgbModal,
    private storageService: StorageService,
  ) { }

  ngOnInit(): void {
    this.userName = this.storageService.getSessionStorage(Constants.STRINGS.USERNAME);
  }
  openWindowCustomClass(content) {
    this.modalService.open(content, { windowClass: 'offcanvas-menu' } );
  }
}
