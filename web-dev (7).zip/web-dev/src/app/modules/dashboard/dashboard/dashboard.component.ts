import { formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { Constants } from 'src/app/constants/constants';
import { SpecificDayClassTeacher } from 'src/app/interfaces/specific-day-class-teacher';
import { TeacherOwnClassData } from 'src/app/interfaces/teacher-own-class-data';
import { DataService } from 'src/app/services/data.service';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  allClasses: TeacherOwnClassData[] = [];
  todayClasses: SpecificDayClassTeacher[] = [];
  assignedHomeWorks = 0;
  assignedTests = 0;
  newBooksArrived = 0;
  activeDoubtSession = 0;
  enrolmentRequestForApproval = 0;
  today = new Date();
  public username!: string;
  customOptions: OwlOptions = {
    loop: false,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: true,
    dots: false,
    navSpeed: 700,
    navText: ['', ''],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 3
      }
    },
    nav: true
  };

  constructor(
    private dataService: DataService,
    private storageService: StorageService
  ) { }

  ngOnInit(): void {
    this.getAllClassDetails();
    this.classesForToday();
    this.username = this.storageService.getSessionStorage(Constants.STRINGS.USERNAME);
  }

  public getAllClassDetails() {
    const userId = this.storageService.getSessionStorage(Constants.STRINGS.USER_ID);
    this.dataService.parseApiCall(
      `${Constants.URL.GET_ALL_CLASS_DETAILS_TEACHER}?userId=${userId}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.allClasses = res.data;
        this.allClasses.forEach(element => {
          this.assignedHomeWorks += element.activity.homeWork;
          this.assignedTests += element.activity.scheduledTest;
          this.newBooksArrived += element.studyMaterials.documentCount;
          this.activeDoubtSession += element.activity.doubtSession;
        });
      }
    });
  }

  public classesForToday() {
    const userId = this.storageService.getSessionStorage(Constants.STRINGS.USER_ID);
    this.dataService.parseApiCall(
      `${Constants.URL.TEACHER_GET_CLASS_SPECIFIC_DAY}?userId=${userId}&day=0${this.today.getDay()===0?7:this.today.getDay()}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.todayClasses = res.data;
      }
    });
  }

}
