import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TeacherPaymentsRoutingModule } from './teacher-payments-routing.module';
import { GlobalModule } from '../global/global.module';
import { AddEditComponent } from './add-edit/add-edit.component';
import { EnrollmentApprovalComponent } from './enrollment-approval/enrollment-approval.component';
import { FeeStructureComponent } from './fee-structure/fee-structure.component';
import { StudentFeePaymentsComponent } from './student-fee-payments/student-fee-payments.component';
import { TeacherPaymentComponent } from './teacher-payment/teacher-payment.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AddEditComponent,
    EnrollmentApprovalComponent,
    FeeStructureComponent,
    StudentFeePaymentsComponent,
    TeacherPaymentComponent
  ],
  imports: [
    CommonModule,
    TeacherPaymentsRoutingModule,
    GlobalModule,
    NgbModule,
    ReactiveFormsModule,
  ]
})
export class TeacherPaymentsModule { }
