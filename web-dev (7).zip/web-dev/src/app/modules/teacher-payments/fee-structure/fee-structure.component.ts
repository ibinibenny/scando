import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Constants } from 'src/app/constants/constants';
import { FeeStructure } from 'src/app/interfaces/fee-structure';
import { DataService } from 'src/app/services/data.service';
import { NavigationService } from 'src/app/services/navigation.service';

@Component({
  selector: 'app-fee-structure',
  templateUrl: './fee-structure.component.html',
  styleUrls: ['./fee-structure.component.css']
})
export class FeeStructureComponent implements OnInit {

  feeStructure: FeeStructure;
  feePaymentTypes = {
    1: 'Monthly',
    2: 'Yearly',
    3: 'Custom'
  }
  feeCollectionTypes = {
    1: 'First day of every month',
    5: 'Fifth day of every month',
    10: 'Tenth day of every month',
    15: 'Fifteenth day of every month',
    20: 'Twentieth day of every month',
    25: 'Twenty Fifth day of every month'
  }
  paymentTimeline = {
    1: '2 days from fee bill',
    2: '5 days from fee bill',
    3: '7 days from fee bill',
  }
  className: string;

  constructor(
    private dataService: DataService,
    private route: ActivatedRoute,
    public navService: NavigationService
  ) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(res => {
      const classId = res.get('classId');
      this.getFeeStructure(classId);
      this.className = res.get('className');
    });
  }

  public getFeeStructure(classId: string) {
    this.dataService.parseApiCall(
      `${Constants.URL.GET_FEE_STRUCTURE}?classId=${classId}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      this.feeStructure = res.data;
    });
  }

}
