import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Constants } from 'src/app/constants/constants';
import { TeacherBankAccount } from 'src/app/interfaces/payment-data';
import { DataService } from 'src/app/services/data.service';
import { NavigationService } from 'src/app/services/navigation.service';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-add-edit',
  templateUrl: './add-edit.component.html',
  styleUrls: ['./add-edit.component.css']
})
export class AddEditComponent implements OnInit {

  accounts: TeacherBankAccount[] = [];

  constructor(
    private dataService: DataService,
    private storageService: StorageService,
    private http: HttpClient,
    public navService: NavigationService
  ) { }

  ngOnInit(): void {
    this.getAccounts();
    this.getBanks();
  }

  public getAccounts() {
    const userId = this.storageService.getSessionStorage(Constants.STRINGS.USER_ID);
    this.dataService.parseApiCall(
      `${Constants.URL.TEACHER_GET_ACCOUNT_LIST}?userId=${userId}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.accounts = res.data;
      }
    });
  }

  public getBanks() {
    this.http.get(
      'https://api.flutterwave.com/v3/banks/NG',
      {
        headers: {
          'Authorization': Constants.FLUTTERWAVE.PUBLIC_KEY
        }
      }
    ).subscribe(res => {

    });
  }

  public deleteAccount(account: TeacherBankAccount) {
    const data = {
      "accountId": account.accountId,
      "accountNumber": account.accountNumber,
      "userId": account.userId
    }
    this.dataService.parseApiCall(
      Constants.URL.DELETE_BANK_ACCOUNT,
      'DELETE',
      data,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      this.getAccounts();
    });
  }

}
