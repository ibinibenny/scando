import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Constants } from 'src/app/constants/constants';
import { OutstandingPaymentListData } from 'src/app/interfaces/outstanding-payment-list-data';
import { PaymentListData } from 'src/app/interfaces/payment-list-data';
import { DataService } from 'src/app/services/data.service';
import { NavigationService } from 'src/app/services/navigation.service';

@Component({
  selector: 'app-student-fee-payments',
  templateUrl: './student-fee-payments.component.html',
  styleUrls: ['./student-fee-payments.component.css']
})
export class StudentFeePaymentsComponent implements OnInit {
  active = 1;
  thisMonthFilter = {
    classId: null,
    startTime: null,
    endTime: null,
    limit: 100,
    page: 1
  }
  tillDateFilter = {
    classId: null,
    startTime: null,
    endTime: null,
    limit: 100,
    page: 1
  }
  outstandingFilter = {
    classId: null,
    startTime: null,
    endTime: null,
    limit: 100,
    page: 1
  }
  className: string;
  thisMonthPayments: PaymentListData[] = [];
  tillDatePayments: PaymentListData[] = [];
  outstandingPayments: OutstandingPaymentListData[] = [];
  thisMonthTotal: number;
  tillDateTotal: number;
  outstandingTotal: number;

  constructor(
    private dataService: DataService,
    private route: ActivatedRoute,
    private toastr: ToastrService,
    public navService: NavigationService
  ) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(res => {
      this.thisMonthFilter.classId = res.get('classId');
      this.tillDateFilter.classId = res.get('classId');
      this.outstandingFilter.classId = res.get('classId');

      this.className = res.get('className');

      const date = new Date();
      this.thisMonthFilter.startTime = new Date(date.getFullYear(), date.getMonth(), 1, 0, 0, 0, 0).getTime();
      this.thisMonthFilter.endTime = new Date(date.getFullYear(), date.getMonth() + 1, 0, 23, 59, 59, 0).getTime();

      this.tillDateFilter.startTime = 0;
      this.tillDateFilter.endTime = Date.now();

      this.outstandingFilter.startTime = new Date(date.getFullYear(), date.getMonth(), 1, 0, 0, 0, 0).getTime();
      this.outstandingFilter.endTime = new Date(date.getFullYear(), date.getMonth() + 1, 0, 23, 59, 59, 0).getTime();

      this.getThismonthPayments();
      this.getTillDatePayments();
      this.getOutstanding();
    });
  }

  public getThismonthPayments() {
    this.dataService.parseApiCall(
      `${Constants.URL.GET_FEE_COLLECTED}?${new URLSearchParams(this.thisMonthFilter as any)}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.thisMonthPayments = res.data.list;
        this.thisMonthTotal = res.data.totalAmount;
      } else {
        this.thisMonthPayments = [];
        this.thisMonthTotal = 0;
      }
    });
  }

  public getTillDatePayments() {
    this.dataService.parseApiCall(
      `${Constants.URL.GET_FEE_COLLECTED}?${new URLSearchParams(this.tillDateFilter as any)}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.tillDatePayments = res.data.list;
        this.tillDateTotal = res.data.totalAmount;
      } else {
        this.tillDatePayments = [];
        this.tillDateTotal = 0;
      }
    });
  }

  public getOutstanding() {
    this.dataService.parseApiCall(
      `${Constants.URL.GET_FEE_OUTSTANDING}?${new URLSearchParams(this.outstandingFilter as any)}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.outstandingPayments = res.data.list;
        this.outstandingTotal = res.data.totalAmount;
      } else {
        this.outstandingPayments = [];
        this.outstandingTotal = 0;
      }
    });
  }

  public sendReminderToStudent(userId: number) {
    const data = {
      title: "Fees reminder",
      message: `You fees for the ${this.className} class is over due`,
      userIds: [userId],
      userType: 1
    };
    this.dataService.parseApiCall(
      Constants.URL.SEND_REMINDER,
      'POST',
      data,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.toastr.success('Reminder send successfully');
      }
    });
  }

}
