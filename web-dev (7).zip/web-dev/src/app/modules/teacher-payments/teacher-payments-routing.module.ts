import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddEditComponent } from './add-edit/add-edit.component';
import { EnrollmentApprovalComponent } from './enrollment-approval/enrollment-approval.component';
import { FeeStructureComponent } from './fee-structure/fee-structure.component';
import { StudentFeePaymentsComponent } from './student-fee-payments/student-fee-payments.component';
import { TeacherPaymentComponent } from './teacher-payment/teacher-payment.component';

const routes: Routes = [
  {
    path: 'add-edit',
    component: AddEditComponent
  },
  {
    path: 'fee-structure/:classId/:className/edit',
    component: EnrollmentApprovalComponent
  },
  {
    path: 'fee-structure/:classId/:className',
    component: FeeStructureComponent
  },
  {
    path: 'student-fee-payments/:classId/:className',
    component: StudentFeePaymentsComponent
  },
  {
    path: 'teacher-payment',
    component: TeacherPaymentComponent
  },
  {
    path: 'edit-account/:accountId/:bank/:accountNumber/:email',
    component: TeacherPaymentComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TeacherPaymentsRoutingModule { }
