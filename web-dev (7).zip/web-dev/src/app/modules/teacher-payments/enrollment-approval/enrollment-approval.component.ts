import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Constants } from 'src/app/constants/constants';
import { FeeStructure } from 'src/app/interfaces/fee-structure';
import { DataService } from 'src/app/services/data.service';
import { NavigationService } from 'src/app/services/navigation.service';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-enrollment-approval',
  templateUrl: './enrollment-approval.component.html',
  styleUrls: ['./enrollment-approval.component.css']
})
export class EnrollmentApprovalComponent implements OnInit {

  feeStructureForm = this.fb.group({
    feePaymentType: [1, Validators.required],
    feeAmount: ['', Validators.required],
    feeCollectionType: [1, Validators.required],
    feePaymentTimeLine: [1, Validators.required],
    feeReminder: [false, Validators.required],
    feeDescription: ['', Validators.required],
    classId: [null, Validators.required],
  });
  feeStructure: FeeStructure;
  className: string;

  constructor(
    private fb: FormBuilder,
    private toastr: ToastrService,
    private route: ActivatedRoute,
    private dataService: DataService,
    private storageService: StorageService,
    public navService: NavigationService,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(res => {
      const classId = res.get('classId');
      this.feeStructureForm.patchValue({classId: classId});
      this.getFeeStructure(classId);
      this.className = res.get('className');
    });
  }

  setCollectionType(type: string) {
    this.feeStructureForm.patchValue({feeCollectionType: type});
  }

  setTimeline(timeline: string) {
    this.feeStructureForm.patchValue({feePaymentTimeLine: timeline});
  }

  public formSubmited() {
    if (this.feeStructureForm.valid) {
      if (this.feeStructure) {
        // Fee structure exists, so update
        const data = {
          classId: this.feeStructureForm.value.classId,
          userId: this.storageService.getSessionStorage(Constants.STRINGS.USER_ID),
          feePaymentType: this.feeStructureForm.value.feePaymentType,
          feeAmount: this.feeStructureForm.value.feeAmount,
          feeCollectionType: this.feeStructureForm.value.feeCollectionType,  
          feePaymentTimeLine: this.feeStructureForm.value.feePaymentTimeLine, 
          feeReminder: this.feeStructureForm.value.feeReminder?1:0,
          feeDescription: this.feeStructureForm.value.feeDescription,
          publishStatus: 1,
        };
        this.dataService.parseApiCall(
          Constants.URL.UPDATE_FEE_STRUCTURE,
          'PUT',
          data,
          this.dataService.getTokenHeader()
        ).subscribe(res => {
          if (res.success) {
            this.toastr.success('Fee structure updated successfully');
            this.router.navigate(['/teacher/payment/fee-structure',data.classId,this.className]);
          } else {
            this.toastr.error('Fee structure updating failed failed');
          }
        });
      } else {
        // No Fee structure exists, so create new
        const data = {
          classId: this.feeStructureForm.value.classId,
          userId: this.storageService.getSessionStorage(Constants.STRINGS.USER_ID),
          userName: this.storageService.getSessionStorage(Constants.STRINGS.USERNAME),
          feePaymentType: this.feeStructureForm.value.feePaymentType,
          feeAmount: this.feeStructureForm.value.feeAmount,
          feeCollectionType: this.feeStructureForm.value.feeCollectionType,  
          feePaymentTimeLine: this.feeStructureForm.value.feePaymentTimeLine, 
          feeReminder: this.feeStructureForm.value.feeReminder?1:0,
          feeDescription: this.feeStructureForm.value.feeDescription,
          publishStatus : 1
        };
        this.dataService.parseApiCall(
          Constants.URL.CREATE_FEE_STRUCTURE,
          'POST',
          data,
          this.dataService.getTokenHeader()
        ).subscribe(res => {
          if (res.success) {
            this.toastr.success('Fee setup completed successfully');
            this.router.navigate(['/teacher/payment/fee-structure',data.classId,this.className]);
          } else {
            this.toastr.error('Fee setup failed');
          }
        });
      }
    } else {
      this.toastr.warning('Enter all required fields');
    }
  }

  public getFeeStructure(classId: string) {
    this.dataService.parseApiCall(
      `${Constants.URL.GET_FEE_STRUCTURE}?classId=${classId}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.feeStructure = res.data;
        this.populateExisting(res.data);
      }
    });
  }

  public populateExisting(data: FeeStructure) {
    this.feeStructureForm.patchValue({
      feePaymentType: data.feePaymentType,
      feeAmount: data.feeAmount,
      feeCollectionType: data.feeCollectionType,
      feePaymentTimeLine: data.feePaymentTimeLine,
      feeReminder: data.feeReminder?true:false,
      feeDescription: data.feeDescription,
    });
  }

}
