import { formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { Constants } from 'src/app/constants/constants';
import { AllClassDetailsData } from 'src/app/interfaces/all-class-details-data';
import { SpecificDayClassTeacher } from 'src/app/interfaces/specific-day-class-teacher';
import { DataService } from 'src/app/services/data.service';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-student-dashboard',
  templateUrl: './student-dashboard.component.html',
  styleUrls: ['./student-dashboard.component.css']
})
export class StudentDashboardComponent implements OnInit {

  allClasses: AllClassDetailsData[] = [];
  assignedHomeWorks = 0;
  assignedTests = 0;
  newBooksArrived = 0;
  activeDoubtSession = 0;
  today = new Date();
  todayClasses: SpecificDayClassTeacher[] = [];
  username!: string;
  customOptions: OwlOptions = {
    loop: false,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: ['', ''],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 4
      }
    },
    nav: true
  };

  constructor(
    private dataService: DataService,
    private storageService: StorageService
  ) { }

  ngOnInit(): void {
    this.getAllClassDetails();
    this.username = this.storageService.getSessionStorage(Constants.STRINGS.USERNAME);
    this.classesForToday();
  }
  public getAllClassDetails() {
    const userId = this.storageService.getSessionStorage(Constants.STRINGS.USER_ID);
    this.dataService.parseApiCall(
      `${Constants.URL.GET_STUDENT_ALL_CLASS_DETAILS}?userId=${userId}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.allClasses = res.data;
        this.allClasses.forEach(element => {
          this.assignedHomeWorks += element.activity.homeWork;
          this.assignedTests += element.activity.scheduledTest;
          this.newBooksArrived += element.studyMaterials.documentCount;
          this.activeDoubtSession += element.activity.doubtSession;
        });
      } else {
        this.allClasses = [];
      }
    });
  }

  public classesForToday() {
    const userId = this.storageService.getSessionStorage(Constants.STRINGS.USER_ID);
    this.dataService.parseApiCall(
      `${Constants.URL.GET_STUDENT_OWN_CLASS}?userId=${userId}&day=0${this.today.getDay()===0?7:this.today.getDay()}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.todayClasses = res.data;
      }
    });
  }

}
