import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StudViewRoutingModule } from './stud-view-routing.module';
import { StudViewComponent } from './stud-view.component';


@NgModule({
  declarations: [
    StudViewComponent
  ],
  imports: [
    CommonModule,
    StudViewRoutingModule
  ]
})
export class StudViewModule { }
