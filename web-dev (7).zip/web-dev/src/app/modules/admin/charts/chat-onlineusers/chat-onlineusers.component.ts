import { Component, OnInit,ViewChild } from '@angular/core';
import { Constants } from 'src/app/constants/constants';
import { DataService } from 'src/app/services/data.service';
import { ApexDataLabels, ApexFill, ApexLegend, ChartComponent } from "ng-apexcharts";
import {
  ApexNonAxisChartSeries,
  ApexResponsive,
  ApexChart,
  ApexTooltip
  } from "ng-apexcharts";
import {
  AllOnlineUsers
} from 'src/app/interfaces/admin-dashboard-response';
export type ChartOptions = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  responsive: ApexResponsive[];
  labels: any;
  fill:ApexFill,
  legend:ApexLegend,
  tooltip:ApexTooltip,
  dataLabels:ApexDataLabels,
  colors;
};

@Component({
  selector: 'app-chat-onlineusers',
  templateUrl: './chat-onlineusers.component.html',
  styleUrls: ['./chat-onlineusers.component.css']
})
export class ChatOnlineusersComponent implements OnInit {
  @ViewChild("chart") chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;
  
  allOnlineUsersCount!: AllOnlineUsers;
  constructor(private dataService: DataService) {
    this.chartOptions = {
      series: [],
      colors : ['#5388D8', '#F4BE37', '#F18412'],
      chart: {
        width: 350,
        height:195,
        type: "pie"
      },
      labels: [],

      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 200
            },
            legend: {
              position: "bottom"
            }
          }
        }
      ],
      tooltip: {
        enabled: false,
      },

      dataLabels: {
        enabled: false,
      },
       
      legend: {
        position: "bottom"
      },
    };
    
   }

  ngOnInit(): void {
    this.getOnlineUserCount();
  }

  getOnlineUserCount() {
    this.dataService
      .parseApiCall(
        Constants.URL.GET_ONLINE_USER_COUNT,
        'GET',
        null,
        this.dataService.getTokenHeader()
      )
      .subscribe((res) => {
        if (res.success && res.data) {
          this.chartOptions.series = [res.data.studentCount, res.data.teacherCount, res.data.adminCount ]
          this.chartOptions.labels = [res.data.studentCount, res.data.teacherCount, res.data.adminCount]
          
          console.log('allOnlineUsersCount:' );
        } else {
          console.log('online user count failed');
        }
      });

  }
 
}
