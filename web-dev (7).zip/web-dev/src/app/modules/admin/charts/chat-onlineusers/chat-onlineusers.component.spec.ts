import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChatOnlineusersComponent } from './chat-onlineusers.component';

describe('ChatOnlineusersComponent', () => {
  let component: ChatOnlineusersComponent;
  let fixture: ComponentFixture<ChatOnlineusersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChatOnlineusersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChatOnlineusersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
