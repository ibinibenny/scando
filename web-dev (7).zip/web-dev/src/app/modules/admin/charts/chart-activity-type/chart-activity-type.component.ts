import { Component, OnInit,ViewChild } from '@angular/core';
import { Constants } from 'src/app/constants/constants';
import { DataService } from 'src/app/services/data.service';
import {
  ApexAxisChartSeries,
  ApexChart,
  ChartComponent,
  ApexDataLabels,
  ApexXAxis,
  ApexPlotOptions,
  ApexStroke,
  ApexTitleSubtitle,
  ApexTooltip,
  ApexFill,
  ApexLegend,
  ApexYAxis,
  ApexGrid,
  
  } from "ng-apexcharts";
export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  xaxis: ApexXAxis;
  yaxis: ApexYAxis;
  stroke: ApexStroke;
  title: ApexTitleSubtitle;
  tooltip: ApexTooltip;
  fill: ApexFill;
  legend: ApexLegend;
  grid:ApexGrid
};
@Component({
  selector: 'app-chart-activity-type',
  templateUrl: './chart-activity-type.component.html',
  styleUrls: ['./chart-activity-type.component.css']
})
export class ChartActivityTypeComponent implements OnInit {
  @ViewChild("chart") chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;
  
  constructor(private dataService: DataService) {
    this.chartOptions = {
    series: [
      {
        data: [44]
      },
      {
         data: [0]
      },
      {
        data: [0]
      },
      {
        data: [0]
      },
     
    ],
    // grid: {
    //   padding: {
    //     left: -5,
    //     right: 0
    //   }
    // },
    grid: {
      show: false,
      borderColor: '#fff',
      strokeDashArray: 0,
      position: 'back',
      xaxis: {
          lines: {
              show: false
          }
      },   
      yaxis: {
          lines: {
              show: false
          }
      },  
      padding: {
          top: 0,
          right: 0,
          bottom: 0,
          left: 0
      },  
  },
    chart: {
      type: "bar",
      height: '100',
      stacked: true,
      stackType: "100%"
    },
    plotOptions: {
      bar: {
        horizontal: true
      }
    },
    stroke: {
      width: 1,
      colors: ["#fff"]
    },
    tooltip: {
      enabled: false,
    },
    xaxis: {
      labels: {
    show: false
  },
  axisBorder: {
    show: false
  },
  axisTicks: {
    show: false
  }
},
yaxis: {
    floating: true,
    axisTicks: {
      show: false
    },
    axisBorder: {
      show: false
    },
    labels: {
      show: false
    },
  },
dataLabels: {
  enabled: false,
  enabledOnSeries: [1]
},
fill: {
  opacity: 1
},
legend: {
  show: false,
  position: "top",
  horizontalAlign: "left",
  offsetX: 40
}
}
}
  ngOnInit(): void {
    // this.getActivityCompletionStatus();
  }
  //  getActivityCompletionStatus() {
  //   // completed
  //    this.dataService
  //     .parseApiCall(
  //       Constants.URL.ACTIVITY_COMPLETION_STATUS,
  //       'GET',
  //       null,
  //       this.dataService.getTokenHeader()
  //     )
  //     .subscribe((res) => {
  //       if (res.success && res.data) {
  //         console.log('activity completion status:', res.data);
  //         this.chartOptions.series = [res.data.tuition]
  //         console.log('getPastActivities:', this.getPastActivities);
  //       } else {
  //         console.log('activity completion status failed');
  //       }
  //     });
  // }
  
}
