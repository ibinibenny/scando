import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChartActivityTypeComponent } from './chart-activity-type.component';

describe('ChartActivityTypeComponent', () => {
  let component: ChartActivityTypeComponent;
  let fixture: ComponentFixture<ChartActivityTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChartActivityTypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChartActivityTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
