import { any } from '@amcharts/amcharts5/.internal/core/util/Array';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chart-gauge',
  templateUrl: './chart-gauge.component.html',
  styleUrls: ['./chart-gauge.component.css']
})
export class ChartGaugeComponent implements OnInit {
  ngOnInit(): void {
 
  }

  constructor() { }
    
  
  


}
