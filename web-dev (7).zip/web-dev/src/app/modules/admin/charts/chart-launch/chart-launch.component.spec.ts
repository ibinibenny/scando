import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChartLaunchComponent } from './chart-launch.component';

describe('ChartLaunchComponent', () => {
  let component: ChartLaunchComponent;
  let fixture: ComponentFixture<ChartLaunchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChartLaunchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChartLaunchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
