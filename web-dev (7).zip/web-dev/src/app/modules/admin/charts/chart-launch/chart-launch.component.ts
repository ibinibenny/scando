import { Component, ViewChild, OnInit } from '@angular/core';
import { Constants } from 'src/app/constants/constants';
import { DataService } from 'src/app/services/data.service';


import {
  ApexNonAxisChartSeries,
  ApexResponsive,
  ApexChart,
  ApexPlotOptions,
  ApexGrid,
  ChartComponent,
  ApexDataLabels,
  ApexTitleSubtitle,
  ApexTooltip,
} from "ng-apexcharts";

export type ChartOptions = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  responsive: ApexResponsive[];
  plotOptions: ApexPlotOptions;
  grid: ApexGrid;
  labels: string[];
  dataLabels: ApexDataLabels;
  title: ApexTitleSubtitle;
  tooltip:ApexTooltip;
  colors;
};

@Component({
  selector: 'app-chart-launch',
  templateUrl: './chart-launch.component.html',
  styleUrls: ['./chart-launch.component.css']
})

export class ChartLaunchComponent implements OnInit {
  @ViewChild("chart") chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;
  totalMinutes:any
  

  constructor(private dataService: DataService) {
    this.chartOptions = {
      series: [],
      colors : ['#60A8EB', '#C4C4C4'],
      chart: {
        width: 380,
        type: "donut"
      },
    plotOptions: {
        pie: {
          startAngle: -90,
          endAngle: 90,
          offsetY: 10,
          donut: {
            size:'70%'
        ,
            labels: {
              show: true,
              total: {
                show: true,
                label: '',
                formatter: () => {
                  let dec = this.totalMinutes - Math.floor(this.totalMinutes);
                  if(dec != 0) {
                    return Math.floor(this.totalMinutes) + " Min " + Math.floor(dec * 100) + " Sec";
                  }
                  return this.totalMinutes +' Min' 
                }
              }
            },


          }
        }
      },
      grid: {
        padding: {
          bottom: -80
        }
      },
      tooltip: {
        enabled: false,
      },
      dataLabels: {
        enabled: false,
      },
       
       responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 200
            },
            legend: {
              position: 'top'
            },
           
          }
        }
      ]
    };
  }
  ngOnInit(): void {
    this.getAverageTimeLaunch();
  }

  getAverageTimeLaunch() {
    
    this.dataService
      .parseApiCall(
        Constants.URL.AVERAGE_TIME_LAUNCH,
        'GET',
        null,
        this.dataService.getTokenHeader()
      )
      .subscribe((res) => {
        if (res.success && res.data) {
          this.totalMinutes = res.data.averageTime//Math.floor(res.data.averageTime / 60);
          this.chartOptions.series = [this.totalMinutes, 5]; 
            
        console.log('average time launch:', res.data);
        } else {
          console.log('average time launch failed');
        }
      });
  }
}
