import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChartLiveclassComponent } from './chart-liveclass.component';

describe('ChartLiveclassComponent', () => {
  let component: ChartLiveclassComponent;
  let fixture: ComponentFixture<ChartLiveclassComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChartLiveclassComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChartLiveclassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
