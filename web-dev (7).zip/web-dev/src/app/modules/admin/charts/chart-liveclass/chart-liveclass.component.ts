import { Component, ViewChild, OnInit, AfterViewInit, AfterViewChecked, AfterContentInit, Input } from '@angular/core';
import { Constants } from 'src/app/constants/constants';
import { DataService } from 'src/app/services/data.service';

import {
  ChartComponent,
  ApexAxisChartSeries,
  ApexChart,
  ApexXAxis,
  ApexDataLabels,
  ApexTooltip,
  ApexStroke,
  ApexLegend,
  ApexYAxis
} from 'ng-apexcharts';

export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  xaxis: ApexXAxis;
  yaxis: ApexYAxis;
  stroke: ApexStroke;
  tooltip: ApexTooltip;
  dataLabels: ApexDataLabels;
  legend: ApexLegend
};

@Component({
  selector: 'app-chart-liveclass',
  templateUrl: './chart-liveclass.component.html',
  styleUrls: ['./chart-liveclass.component.css'],
})
export class ChartLiveclassComponent implements OnInit, AfterContentInit {
  @ViewChild('chart') chart: ChartComponent;


  public chartOptions: Partial<ChartOptions>;

  studentLiveCount: number[] = [];
  scheduleClassCount: number[] = [];
  studentLiveTime: any[] = [];

  liveEnabled: boolean = true;
  scheduledEnabled: boolean = false;

  constructor(private dataService: DataService) {
    this.chartOptions = {
      series: [
        {
          name: 'live',
          data: [2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28],
          color: "#b6b6b6"
        },
        {
          name: "scheduled",
          data: [11, 32, 45, 32, 34, 52, 41, 30, 24, 28, 27, 20, 12, 18],
          color: "#e0deec"
        }
      ],
      chart: {
        height: 257,
        type: 'line',
        width: 450
      },

      dataLabels: {
        enabled: false,
      },
      stroke: {
        curve: 'smooth',
        width: 2
      },
      xaxis: {
        type: 'datetime',
        categories: [
          '2022-08-10T06:30:00.002Z',
          '2022-08-10T07:30:00.001Z',
          '2022-08-10T08:30:00.001Z',
          '2022-08-10T09:30:00.001Z',
          '2022-08-10T10:30:00.001Z',
          '2022-08-10T11:30:00.001Z',
          '2022-08-10T12:30:00.001Z',
          '2022-08-10T13:30:00.001Z',
          '2022-08-10T14:30:00.001Z',
          '2022-08-10T15:30:00.001Z',
          '2022-08-10T16:30:00.001Z',
          '2022-08-10T16:30:00.001Z',
          '2022-08-10T17:30:00.001Z',
          '2022-08-10T17:30:00.001Z'
        ],
      },
      // yaxis: {
      //   title: {
      //     text: "No of live classes",

      //   }
      // },
      legend: {
        show: false,
        position: 'top',
        horizontalAlign: 'left'
      },

    };
    this.getLiveCount();
  }
  ngAfterContentInit(): void {
   
  }


  ngOnInit(): void {

  }


  changeLive($event) {
    this.liveEnabled = this.liveEnabled || $event.target.checked;
    this.scheduledEnabled = false;
    if ($event.target.checked)
   { this.chartOptions.series = [{
    name: "live",
    data: [...this.studentLiveCount],
    color: "#b6b6b6"
  },
  {
    name: "scheduled",
    data: [...this.scheduleClassCount],
    color: "#e0deec"
  }
  ];
  }
}


  changeScheduled($event) {
    this.scheduledEnabled = this.scheduledEnabled || $event.target.checked;
    this.liveEnabled = false;
    if ($event.target.checked)
    { this.chartOptions.series = [{
     name: "live",
     data: [...this.studentLiveCount],
     color: "#e0deec"
   },
   {
     name: "scheduled",
     data: [...this.scheduleClassCount],
     color: "#b6b6b6"
   }
   ];
   }
  }



  getLiveCount() {
    const startTime = new Date();
    startTime.setUTCHours(0, 0, 0, 0);
    const startOfDay = startTime.getTime();

    const endTime = new Date();
    endTime.setUTCHours(23, 59, 59, 999);
    const endOfDay = endTime.getTime();
    this.dataService
      .parseApiCall(
        `${Constants.URL.LIVE_SCHEDULE_COUNT}?endTime=${endOfDay}&startTime=${startOfDay}`,
        'GET',
        null,
        this.dataService.getTokenHeader()
      )
      .subscribe((res) => {
        if (res.success && res.data) {
         // let scheduleClassCount = [];
          for (let studentData of res?.data) {
          //  if (studentData.liveClassCount > 0 || studentData.scheduleClassCount > 0) {

              this.scheduleClassCount.push(studentData.scheduleClassCount);
              this.studentLiveCount.push(studentData.liveClassCount);

              const meanTime = (studentData.endTime + studentData.startTime) / 2;
              const meanDate = new Date(meanTime).toISOString();
              this.studentLiveTime.push(meanDate);
            }
     //     }
        //  if (this.studentLiveCount.length > 0 || this.scheduleClassCount.length > 0) {
            this.chartOptions.series = [{
              name: "live",
              data: [...this.studentLiveCount],
              color: "#b6b6b6"
            },
            {
              name: "scheduled",
              data: [...this.scheduleClassCount],
              color: "#e0deec"
            }
            ];

            this.chartOptions.xaxis = {
              type: 'datetime',
              categories: [...this.studentLiveTime]
            };
         // }
          console.log('studentLiveCount', this.studentLiveTime);
        } else {
          // console.log('this is online user count failed message');
        }
      });
  }

}
