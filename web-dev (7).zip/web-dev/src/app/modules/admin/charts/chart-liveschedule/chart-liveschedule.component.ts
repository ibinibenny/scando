import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chart-liveschedule',
  templateUrl: './chart-liveschedule.component.html',
  styleUrls: ['./chart-liveschedule.component.css']
})
export class ChartLivescheduleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
