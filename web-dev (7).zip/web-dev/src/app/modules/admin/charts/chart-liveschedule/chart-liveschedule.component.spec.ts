import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChartLivescheduleComponent } from './chart-liveschedule.component';

describe('ChartLivescheduleComponent', () => {
  let component: ChartLivescheduleComponent;
  let fixture: ComponentFixture<ChartLivescheduleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChartLivescheduleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChartLivescheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
