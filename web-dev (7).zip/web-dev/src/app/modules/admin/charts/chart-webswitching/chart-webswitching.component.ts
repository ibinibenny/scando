import { Component, ViewChild, OnInit } from '@angular/core';
import { Constants } from 'src/app/constants/constants';
import { DataService } from 'src/app/services/data.service';

import {
  ApexNonAxisChartSeries,
  ApexResponsive,
  ApexChart,
  ApexPlotOptions,
  ApexGrid,
  ChartComponent,
  ApexTooltip,
  ApexDataLabels
} from "ng-apexcharts";

export type ChartOptions = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  responsive: ApexResponsive[];
  plotOptions: ApexPlotOptions;
  grid: ApexGrid;
  labels: string[];
  tooltip:ApexTooltip;
  dataLabels:ApexDataLabels;
  colors;
};
@Component({
  selector: 'app-chart-webswitching',
  templateUrl: './chart-webswitching.component.html',
  styleUrls: ['./chart-webswitching.component.css']
})
export class ChartWebswitchingComponent implements OnInit {
  @ViewChild("chart") chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;
  totalMinutes:any

  constructor(private dataService: DataService) {
    this.chartOptions = {
      colors : ['#60A8EB', '#C4C4C4'],
      series: [],
      chart: {
        width: 380,
        type: "donut"
      },
    plotOptions: {
        pie: {
          startAngle: -90,
          endAngle: 90,
          offsetY: 10,
          donut: {
            size:'70%'
        ,
            labels: {
              show: true,
              total: {
                show: true,
                label: '',
                formatter: () => this.totalMinutes +' Sec' 
              }
            }

          }
        }
      },
      grid: {
        padding: {
          bottom: -80
        }
      },
      tooltip: {
        enabled: false,
      },
      dataLabels: {
        enabled: false,
      },
       
       responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 200
            },
            legend: {
              position: 'top'
            },
           
          }
        }
      ]
    };
  }

  ngOnInit(): void {
    this.getAverageTimeLaunch();
  }

  getAverageTimeLaunch() {
    
    this.dataService
      .parseApiCall(
        Constants.URL.AVERAGE_TIME_LAUNCH,
        'GET',
        null,
        this.dataService.getTokenHeader()
      )
      .subscribe((res) => {
        if (res.success && res.data) {
          this.totalMinutes = Math.floor(res.data.averageTime);
          this.chartOptions.series = [this.totalMinutes, res.data.averageTime]; 
            
        console.log('average time launch:', res.data);
        } else {
          console.log('average time launch failed');
        }
      });
  }
}
