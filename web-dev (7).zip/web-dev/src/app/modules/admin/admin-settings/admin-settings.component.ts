import { Component, OnInit } from '@angular/core';
import { Constants } from 'src/app/constants/constants';
import { AdminProperties } from 'src/app/interfaces/admin-dashboard-response';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-admin-settings',
  templateUrl: './admin-settings.component.html',
  styleUrls: ['./admin-settings.component.css'],
})
export class AdminSettingsComponent implements OnInit {
  adminProperties: AdminProperties;
  public username!: string;
  today = new Date();
  constructor(private dataService: DataService) { }

  ngOnInit(): void {
    this.getAdminProperties();
  }

  /**
   * @author Jobin Jacob Paily
   * @param $event 
   *  Select all properties enable/disable
   */
  selectAll($event) {
    this.setAllValues($event.target.checked);
    this.saveAdminProperties();
  }

  setAllValues(value: boolean) {
    this.adminProperties.activityLocation = value;
    this.adminProperties.avgTimeAnalytics = value;
    this.adminProperties.liveScheduleGraph = value;
    this.adminProperties.onlineUsers = value;
  }

/*---------------------------------------------------*/

  onChange(event: any) {
    this.saveAdminProperties();
  }
  getAdminProperties() {
    // completed
    this.dataService
      .parseApiCall(
        Constants.URL.GET_PROPERTY,
        'GET',
        null,
        this.dataService.getTokenHeader()
      )
      .subscribe((res) => {
        if (res.success && res.data) {
          this.adminProperties = res.data;
          console.log('admin properties:', res.data);
          sessionStorage.setItem("AdminProperties" , JSON.stringify(this.adminProperties));
        } else {
          console.log('admin properties failed');
        }
      });
  }

  saveAdminProperties() {
    console.log(this.adminProperties, "admin properties")
    this.dataService
      .parseApiCall(
        Constants.URL.SAVE_PROPERTY,
        'POST',
        this.adminProperties,
        // this.adminProperties,
        this.dataService.getTokenHeader()
      )
      .subscribe((res) => {
        console.log('properties:', res);
        if (res.success && res.data) {
          console.log('admin properties:', res.data);
          this.getAdminProperties();
        } else {
          console.log('admin properties failed');
        }
      });
  }
}
