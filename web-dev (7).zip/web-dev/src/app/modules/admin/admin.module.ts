import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminRoutingModule } from './admin-routing.module';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { FormsModule } from '@angular/forms';
import { AdminSettingsComponent } from './admin-settings/admin-settings.component';
import { ChartLiveclassComponent } from './charts/chart-liveclass/chart-liveclass.component';
import { NgApexchartsModule } from 'ng-apexcharts';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { ChartLaunchComponent } from './charts/chart-launch/chart-launch.component';
import { ChartWebswitchingComponent } from './charts/chart-webswitching/chart-webswitching.component';
import { ChatOnlineusersComponent } from './charts/chat-onlineusers/chat-onlineusers.component';
import { ChartActivityTypeComponent } from './charts/chart-activity-type/chart-activity-type.component';
import { ChartGaugeComponent } from './charts/chart-gauge/chart-gauge.component';
import { ChartLivescheduleComponent } from './charts/chart-liveschedule/chart-liveschedule.component';








@NgModule({
  declarations: [
    AdminDashboardComponent,
    AdminSettingsComponent,
    ChartLiveclassComponent,
    ChartLaunchComponent,
    ChartWebswitchingComponent,
    ChatOnlineusersComponent,
    ChartActivityTypeComponent,
    ChartGaugeComponent,
    ChartLivescheduleComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    FormsModule,
    NgApexchartsModule,
    TabsModule
  ]
})
export class AdminModule { }
