import { Component, OnInit } from '@angular/core';
import { Constants } from 'src/app/constants/constants';
import {
  AllClassTypesInfo,
  AllOnlineUsers,
  GetAllRegisteredUsers,
  GetPastActivities,
  AverageLaunchTime,
  AdminProperties,
  } from 'src/app/interfaces/admin-dashboard-response';
import { DataService } from 'src/app/services/data.service';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css'],
})
export class AdminDashboardComponent implements OnInit {
  classTypeCounts: any;
  classTypeCount: any = {};
  totalClassTypeCOunt:any;
  showSettings!: Boolean;
  allOnlineUsersCount!: AllOnlineUsers;
  getPastActivities!: GetPastActivities;
  getPastActivitiesTotal = 0;
  allRegisteredUsers!: GetAllRegisteredUsers;
  classTypeInfo!: AllClassTypesInfo;
  averageLaunchTime!: AverageLaunchTime;
  public username!: string;
  adminProperties:AdminProperties;
  today = new Date();
  constructor(private dataService: DataService,
     private storageService: StorageService
    ) {}

  ngOnInit(): void {
    let settings = sessionStorage.getItem("AdminProperties");
    if(settings == null) {
      this.getAdminProperties();
    } else {
      this.adminProperties = JSON.parse(settings);
    }

    console.log("AdminProperties => " ,this.adminProperties);

    this.showSettings = false;
    this.username = this.storageService.getSessionStorage(Constants.STRINGS.USERNAME);
    this.getOnlineUserCount();
    this.getUserStatusCount();
    this.getClassTypeCount();
    this.getAllClassTypeInfo();
    this.getAverageTimeLaunch();
    this.getActivityCompletionStatus();
    this.getLiveScheduleCount();
  }

  getAdminProperties() {
    // completed
    this.dataService
      .parseApiCall(
        Constants.URL.GET_PROPERTY,
        'GET',
        null,
        this.dataService.getTokenHeader()
      )
      .subscribe((res) => {
        if (res.success && res.data) {
          this.adminProperties = res.data;
          sessionStorage.setItem("AdminProperties" , JSON.stringify(this.adminProperties));
          console.log("AdminProperties => " ,res.data);
          console.log('admin properties:', res.data);
        } else {
          console.log('admin properties failed');
        }
      });
  }

  // getClassTypeCount() {
  //   // almost completed
  //   const currentDate = new Date();
  //   const day = currentDate.toLocaleDateString('en-US', { weekday: 'long' });
  //   const currentHour = currentDate.getHours();
  //   console.log('currentHour:', currentHour);
  //   this.dataService
  //     .parseApiCall(
  //       `${Constants.URL.CLASS_TYPE_COUNT}?day=${day}&startTime=${currentHour}`,
  //       'GET',
  //       null,
  //       this.dataService.getTokenHeader()
  //     )
  //     .subscribe((res) => {
  //       if (res.success && res.data) {
  //         this.getClassTypeCount = res.data;
  //         console.log('class type count:', res.data);
  //       } else {
  //         console.log('class type count failed');
  //       }
  //     });
  // }
  getClassTypeCount() {
   const currentDate = new Date();
    // const day = currentDate.toLocaleDateString('en-US', { weekday: 'long' });
    // const day = `0${currentDate.getDay() + 1}`;
    let day = "";
if(currentDate.getDay() == 6) {
    day = `06`
} else
   {
       day = `0${currentDate.getDay()}`
   }
  
    const currentHour = currentDate.getUTCMilliseconds();
    // console.log('currentHour:', currentHour);
    this.dataService
    .parseApiCall(
      `${Constants.URL.CLASS_TYPE_COUNT}?day=${day}&startTime=${currentHour}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    )
    .subscribe((res) => {
      if (res.success && res.data) {
        // console.log('activity completion status:', res.data);
        this.classTypeCounts = res.data;
        let event = res.data.filter(el => el.classTypeName == "Events");
        let hobbies = res.data.filter(el => el.classTypeName == "hobbies");
        let tution = res.data.filter(el => el.classTypeName == "Tuition");
        let random = res.data.filter(el => el.classTypeName == "Randoms");

        this.classTypeCount.events = event.length == 0 ? 0 : event[0].classCount;
        this.classTypeCount.hobbies = hobbies.length == 0 ? 0 : hobbies[0].classCount;
        this.classTypeCount.tuitions = tution.length == 0 ? 0 : tution[0].classCount;
        this.classTypeCount.randoms = random.length == 0 ? 0 : random[0].classCount;
        
      
        this.totalClassTypeCOunt = res.data.reduce((partialSum, a) => partialSum + a.classCount, 0);
       console.log('getClassTypeCount:', this.totalClassTypeCOunt);
       console.log('classTypeCount : ', this.classTypeCount);
      } else {
        console.log('activity completion status failed');
      }
    });
  }







  getAllClassTypeInfo() {
    // completed
    const currentDate = new Date();
    const currentTimeStamp = currentDate.getTime();
    this.dataService
      .parseApiCall(
        `${Constants.URL.CLASS_TYPE_INFO}?date=${currentTimeStamp}`,
        'GET',
        null,
        this.dataService.getTokenHeader()
      )
      .subscribe((res) => {
        if (res.success && res.data) {
        this.classTypeInfo = res.data;
          console.log('all class type count:', res.data);
        } else {
          console.log('all class type count failed');
        }
      });
  }

  getOnlineUserCount() {
    this.dataService
      .parseApiCall(
        Constants.URL.GET_ONLINE_USER_COUNT,
        'GET',
        null,
        this.dataService.getTokenHeader()
      )
      .subscribe((res) => {
        if (res.success && res.data) {
          this.allOnlineUsersCount = res.data;
          console.log('allOnlineUsersCount:', this.allOnlineUsersCount);
        } else {
          console.log('online user count failed');
        }
      });
  }

  getUserStatusCount() {
    // completed
    this.dataService
      .parseApiCall(
        Constants.URL.USER_STATUS_COUNT,
        'GET',
        null,
        this.dataService.getTokenHeader()
      )
      .subscribe((res) => {
        if (res.success && res.data) {
          // console.log('user status count:', res.data);
          this.allRegisteredUsers = res.data;
          // console.log('allRegisteredUsers:', this.allRegisteredUsers);
        } else {
          console.log('user status count failed');
        }
      });
  }

  getAverageTimeLaunch() {
    // completed
    this.dataService
      .parseApiCall(
        Constants.URL.AVERAGE_TIME_LAUNCH,
        'GET',
        null,
        this.dataService.getTokenHeader()
      )
      .subscribe((res) => {
        if (res.success && res.data) {
          this.averageLaunchTime = res.data;
          // console.log('average time launch:', res.data);
        } else {
          console.log('average time launch failed');
        }
      });
  }

  async getActivityCompletionStatus() {
    // completed
    await this.dataService
      .parseApiCall(
        Constants.URL.ACTIVITY_COMPLETION_STATUS,
        'GET',
        null,
        this.dataService.getTokenHeader()
      )
      .subscribe((res) => {
        if (res.success && res.data) {
          // console.log('activity completion status:', res.data);
          this.getPastActivities = res.data;
          this.getPastActivitiesTotal = this.getPastActivities.tuition + this.getPastActivities.events + this.getPastActivities.hobbies + this.getPastActivities.others;
          // console.log('getPastActivities:', this.getPastActivities);
        } else {
          console.log('activity completion status failed');
        }
      });
  }

  getLiveScheduleCount() {
    // almost completed
    const currentDate = new Date();
    const tomorrow = new Date(currentDate);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const startTime = currentDate.getTime();
    const endTime = tomorrow.getTime();
    console.log('currentDate:',currentDate);
    console.log('tomorrow:',tomorrow);
    console.log('tomorrow:',tomorrow);
    console.log('startTime:',startTime);
    console.log('endTime:',endTime);
    this.dataService
      .parseApiCall(
        `${Constants.URL.LIVE_SCHEDULE_COUNT}?endTime=${endTime}&startTime=${startTime}`,
        'GET',
        null,
        this.dataService.getTokenHeader()
      )
      .subscribe((res) => {
        if (res.success && res.data) {
          console.log('live schedule count:', res.data);
        } else {
          console.log('live schedule count failed');
        }
      });
  }
}
