import { Component, ContentChild, Input, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DataService } from 'src/app/services/data.service';
import { Constants } from 'src/app/constants/constants';
import { StorageService } from 'src/app/services/storage.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-signup',
  templateUrl: './admin-signup.component.html',
  styleUrls: ['./admin-signup.component.css']
})
export class AdminSignupComponent implements OnInit {
  @ViewChild("passWord") input : HTMLInputElement;

  showPassword:boolean = false;

  loginForm = new FormGroup({
    username: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required])
  });

  constructor(
    private dataService: DataService,
    private storageService: StorageService,
    private toastr: ToastrService,
    private router: Router,
  ) { }

  ngOnInit(): void {

  }

  showPasswordFn() {
    this.showPassword = !this.showPassword;
    
  }

  public submitForm() {
    if (this.loginForm.valid) {
      const appId = this.storageService.getLocalStorage(Constants.STRINGS.APP_ID);
      const data = {
        appId: appId,
        username: this.loginForm.value.username,
        password: this.loginForm.value.password
      };
      this.dataService.parseApiCall(
        Constants.URL.ADMIN_LOGIN,
        'POST',
        data,
        this.dataService.getCommonHeader()
      ).subscribe(res => {
        if (res.success) {
          if (res.data.code === 0) {
            this.storageService.setSessionStorage(
              Constants.STRINGS.TOKEN,
              res.data.token
            );
            this.storageService.setSessionStorage(
              Constants.STRINGS.USER_ID,
              res.data.userId
            );
            const userType = res.data.userType;
            this.storageService.setSessionStorage(Constants.STRINGS.USER_TYPE, userType);
            this.storageService.setSessionStorage(Constants.STRINGS.USERNAME, res.data.userName);
            this.router.navigate(['/admin']);
          } else if (res.data.code === 1) {
            // Account not exists
          } else {
            // Invalid OTP
          }
        } else {
          console.log('failed');
          this.toastr.error(res.message);
        }
      });
    }
  }

}
