import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Constants } from 'src/app/constants/constants';
import { DataService } from 'src/app/services/data.service';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-otp-verification',
  templateUrl: './otp-verification.component.html',
  styleUrls: ['./otp-verification.component.css'],
})
export class OtpVerificationComponent implements OnInit {
  type!: number;
  mobile!: string;
  otpForm = new FormGroup({
    otp1: new FormControl(undefined, [
      Validators.required,
      Validators.maxLength(1),
      Validators.minLength(1),
    ]),
    otp2: new FormControl(undefined, [
      Validators.required,
      Validators.maxLength(1),
      Validators.minLength(1),
    ]),
    otp3: new FormControl(undefined, [
      Validators.required,
      Validators.maxLength(1),
      Validators.minLength(1),
    ]),
    otp4: new FormControl(undefined, [
      Validators.required,
      Validators.maxLength(1),
      Validators.minLength(1),
    ]),
  });

  constructor(
    private route: ActivatedRoute,
    private storageService: StorageService,
    private dataService: DataService,
    private router: Router,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe((res) => {
      this.type = Number(res.get('type'));
      const mobile = res.get('mobile');
      if (mobile) {
        this.mobile = mobile;
      }
    });
    this.otpForm.controls.otp1.valueChanges.subscribe((value) => {});
  }

  public onEdit() {
    console.log('Edit clicked', this.mobile);
    console.log('Edit', this.type);
    this.router.navigate(['/login', this.type]);
  }

  public toAutoFocus(event: any) {
    if (event.type === 'keyup' && event.code !== 'Backspace') {
      const nextInput = event.srcElement.nextElementSibling;
      if (nextInput == null) return;
      else nextInput.focus();
    } else {
      const nextInput = event.srcElement.previousElementSibling;
      if (nextInput == null) return;
      else nextInput.focus();
    }
  }

  public verifyOtp() {
    console.log('otp:', this.otpForm.valid);

    if (this.otpForm.valid) {
      const data = {
        number: this.mobile,
        appId: this.storageService.getLocalStorage(Constants.STRINGS.APP_ID),
        otp: `${this.otpForm.value.otp1}${this.otpForm.value.otp2}${this.otpForm.value.otp3}${this.otpForm.value.otp4}`,
      };
      console.log('data:', data);
      this.dataService
        .parseApiCall(
          Constants.URL.VERIFY_OTP,
          'POST',
          data,
          this.dataService.getCommonHeader()
        )
        .subscribe((res) => {
          console.log('res:', res);
          if (res.success) {
            if (res.data.code === 0) {
              this.storageService.setSessionStorage(
                Constants.STRINGS.TOKEN,
                res.data.token
              );
              this.storageService.setSessionStorage(
                Constants.STRINGS.USER_ID,
                res.data.userId
              );
              const userType = res.data.userType;
              this.storageService.setSessionStorage(
                Constants.STRINGS.USER_TYPE,
                userType
              );
              this.storageService.setSessionStorage(
                Constants.STRINGS.USERNAME,
                res.data.userName
              );
              if (userType === 0) {
                this.router.navigate(['/teacher/dashboard']);
              } else {
                this.router.navigate(['/student/dashboard']);
              }
            } else if (res.data.code === 1) {
              // Account not exists
              this.router.navigate([
                '/login',
                this.type,
                this.mobile,
                'signup',
              ]);
            } else {
              // Invalid OTP
            }
          } else {
            console.log('failed');
            this.toastr.error(res.message);
          }
        });
    } else {
      console.log('form is not valid');
      this.toastr.error('OTP is not valid');
    }
  }

  public resendOtp() {
    if (this.mobile) {
      const data = {
        number: this.mobile,
        appId: this.storageService.getLocalStorage(Constants.STRINGS.APP_ID),
      };
      console.log('data:', data);
      this.dataService
        .parseApiCall(
          Constants.URL.GENERATE_OTP,
          'POST',
          data,
          this.dataService.getCommonHeader()
        )
        .subscribe((res) => {
          if (res.success) {
            console.log('otp generated successful');
          } else {
            console.log('failed');
          }
        });
    } else {
      console.log('form is not valid');
    }
  }
}
