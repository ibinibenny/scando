import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DataService } from 'src/app/services/data.service';
import { StorageService } from 'src/app/services/storage.service';
import { Constants } from 'src/app/constants/constants';

@Component({
  selector: 'app-student-signup',
  templateUrl: './student-signup.component.html',
  styleUrls: ['./student-signup.component.css'],
})
export class StudentSignupComponent implements OnInit {
  type!: number;
  mobile!: string;

  studentRegForm = new FormGroup({
    userName: new FormControl(undefined, [
      Validators.required,
      Validators.minLength(3),
    ]),
  });
  constructor(
    private storageService: StorageService,
    private dataService: DataService,
    private toastr: ToastrService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe((res) => {
      this.type = Number(res.get('type'));
      const mobile = res.get('mobile');
      if (mobile) {
        this.mobile = mobile;
      }
    });
  }

  // For student registrations
  public studentSignUp() {
    console.log('otp:', this.studentRegForm.valid);

    if (this.studentRegForm.valid) {
      const data = {
        number: this.mobile,
        userName: this.studentRegForm.value.userName,
        profileId: 1,
        appId: this.storageService.getLocalStorage(Constants.STRINGS.APP_ID),
      };
      console.log('data:', data);
      this.dataService
        .parseApiCall(
          Constants.URL.STUDENT_SIGNUP,
          'POST',
          data,
          this.dataService.getCommonHeader()
        )
        .subscribe((res) => {
          console.log('res:', res);
          if (res.success) {
            this.storageService.setSessionStorage(
              Constants.STRINGS.TOKEN,
              res.data.token
            );
            this.storageService.setSessionStorage(
              Constants.STRINGS.USER_ID,
              res.data.userId
            );
            const userType = res.data.userType;
            this.storageService.setSessionStorage(
              Constants.STRINGS.USER_TYPE,
              userType
            );
            this.storageService.setSessionStorage(
              Constants.STRINGS.USERNAME,
              res.data.userName
            );
            this.router.navigate(['/student/dashboard']);
          } else {
            console.log('failed');
          }
        });
    } else {
      console.log('form is not valid');
      this.toastr.error(
        'Student registration form is not valid, username filed is mandatory.'
      );
    }
  }
}
