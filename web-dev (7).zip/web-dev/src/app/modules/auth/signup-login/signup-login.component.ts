import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import {
  CountryISO,
  PhoneNumberFormat,
  SearchCountryField,
} from 'ngx-intl-tel-input';
import { ToastrService } from 'ngx-toastr';
import { Constants } from 'src/app/constants/constants';
import { DataService } from 'src/app/services/data.service';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-signup-login',
  templateUrl: './signup-login.component.html',
  styleUrls: ['./signup-login.component.css'],
})
export class SignupLoginComponent implements OnInit {
  separateDialCode = false;
  SearchCountryField = SearchCountryField;
  CountryISO = CountryISO;
  PhoneNumberFormat = PhoneNumberFormat;
  preferredCountries: CountryISO[] = [CountryISO.India];
  phoneForm = new FormGroup({
    phone: new FormControl(undefined, [Validators.required]),
  });
  type!: number;

  constructor(
    private toastr: ToastrService,
    private dataService: DataService,
    private route: ActivatedRoute,
    private storageService: StorageService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe((res) => {
      this.type = Number(res.get('type'));
    });
    if (this.phoneForm.value.phone == null) {
      this.phoneForm.controls['phone'].setValue(
        this.storageService.getSessionStorage('PHONE_NUMBER')
      );
    }
  }

  public getOtpClicked() {
    console.log('phone:', this.phoneForm.value.phone.e164Number);
    if (this.phoneForm.valid) {
    this.storageService.setSessionStorage(
      'PHONE_NUMBER',
      this.phoneForm.value.phone
    );
    this.generateOtp();
    } else {
      this.toastr.error('Enter a valid mobile number');
    }
  }

  public generateOtp() {
    // if (this.phoneForm.valid) {
    const data = {
      number: this.phoneForm.value.phone.e164Number,
      appId: this.storageService.getLocalStorage(Constants.STRINGS.APP_ID),
    };
    console.log('data:', data);
    this.dataService
      .parseApiCall(
        Constants.URL.GENERATE_OTP,
        'POST',
        data,
        this.dataService.getCommonHeader()
      )
      .subscribe((res) => {
        if (res.success) {
          console.log('otp generated successful');
          // this.router.navigateByUrl(this.phoneForm.value.phone.e164Number);
          this.router.navigate([
            '/login',
            this.type,
            this.phoneForm.value.phone.e164Number,
          ]);
        } else {
          console.log('failed');
        }
      });
    // } else {
    //   console.log('form is not valid');
    // }
  }
}
