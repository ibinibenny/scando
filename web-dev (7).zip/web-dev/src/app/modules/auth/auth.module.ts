import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { SignupLoginComponent } from './signup-login/signup-login.component';
import { OtpVerificationComponent } from './otp-verification/otp-verification.component';
import { NgxIntlTelInputModule } from 'ngx-intl-tel-input';
import { RouterModule } from '@angular/router';
import { TeacherSignupComponent } from './teacher-signup/teacher-signup.component';
import { StudentSignupComponent } from './student-signup/student-signup.component';
import { AdminSignupComponent } from './admin-signup/admin-signup.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    LoginComponent,
    SignupComponent,
    SignupLoginComponent,
    OtpVerificationComponent,
    TeacherSignupComponent,
    StudentSignupComponent,
    AdminSignupComponent

  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NgxIntlTelInputModule,
    RouterModule,
    HttpClientModule
  ]
})
export class AuthModule { }
