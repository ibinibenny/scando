import { Component, OnInit } from '@angular/core';
import { Constants } from 'src/app/constants/constants';
import { DataService } from 'src/app/services/data.service';
import { DeviceDetectorService } from 'ngx-device-detector';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { StorageService } from 'src/app/services/storage.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  public studentsLoginForm: FormGroup;
  public teachersLoginForm: FormGroup;
  public otpGenerateForm: FormGroup;
  public otpVerifyForm: FormGroup;
  public checkAccountForm: FormGroup;
  public selectedType!: number;

  constructor(
    private api: DataService,
    private formBuilder: FormBuilder,
    private deviceService: DeviceDetectorService,
    private storageService: StorageService,
    private router: Router
  ) {
    // Formbuilder for student login form
    this.studentsLoginForm = this.formBuilder.group({
      userName: new FormControl(
        '',
        Validators.compose([Validators.required, Validators.minLength(3)])
      ),
      number: new FormControl(
        '',
        Validators.compose([Validators.required, Validators.minLength(10)])
      ),
    });

    // Formbuilder for reacher login form
    this.teachersLoginForm = this.formBuilder.group({
      userName: new FormControl(
        '',
        Validators.compose([Validators.required, Validators.minLength(3)])
      ),
      number: new FormControl(
        '',
        Validators.compose([Validators.required, Validators.minLength(10)])
      ),
    });

    // Formbuilder for otp generate
    this.otpGenerateForm = this.formBuilder.group({
      number: new FormControl(
        '',
        Validators.compose([Validators.required, Validators.minLength(10)])
      ),
    });

    // Formbuilder for otp verify
    this.otpVerifyForm = this.formBuilder.group({
      number: new FormControl(
        '',
        Validators.compose([Validators.required, Validators.minLength(10)])
      ),
      otp: new FormControl(
        '',
        Validators.compose([Validators.required, Validators.min(4)])
      ),
    });

    // Formbuilder for check account
    this.checkAccountForm = this.formBuilder.group({
      mobileNumber: new FormControl(
        '',
        Validators.compose([Validators.required, Validators.minLength(10)])
      ),
    });
  }

  ngOnInit(): void {
    if (!this.storageService.isKeyExistInLocal(Constants.STRINGS.APP_ID)) {
      this.registerApp();
    }
  }

  //For registering user device details
  private registerApp() {
    const device = this.deviceService.getDeviceInfo();
    console.log(device);
    const deviceId = `${device.browser}-${
      device.browser_version
    }-${new Date().getTime()}`;
    const data = {
      appVersion: Constants.VERSION,
      deviceId: deviceId,
      deviceInfo: `${device.browser}-${device.browser_version}`,
      deviceToken: 'thga3i943459vgfgakjflgkj__935_fhdjsahewjhrtq',
      osInfo: this.deviceService.os_version,
    };
    console.log('data:', data);
    this.api
      .parseApiCall(
        Constants.URL.APP_REGISTRATION,
        'POST',
        data,
        this.api.getCommonHeader()
      )
      .subscribe((res) => {
        console.log(res);
        if (res.success) {
          this.storageService.setLocalStorage(
            Constants.STRINGS.APP_ID,
            res.data.appId
          );
        } else {
          console.log('failed');
        }
      });
  }

  //For students login
  public studentLogin() {
    console.log('loginForm:', this.studentsLoginForm.valid);

    if (this.studentsLoginForm.valid) {
      const data = {
        userName: this.studentsLoginForm.value.userName,
        number: this.studentsLoginForm.value.number,
      };
      console.log('data:', data);
      this.api
        .parseApiCall(
          Constants.URL.STUDENT_SIGNUP,
          'POST',
          data,
          this.api.getCommonHeader()
        )
        .subscribe((res) => {
          console.log('res:', res);
          if (res.success) {
            console.log('student registration successful');
          } else {
            console.log('failed');
          }
        });
    } else {
      console.log('form is not valid');
    }
  }

  //For teachers login
  public teacherLogin() {
    console.log('loginForm:', this.teachersLoginForm.valid);

    if (this.teachersLoginForm.valid) {
      const data = {
        userName: this.teachersLoginForm.value.userName,
        number: this.teachersLoginForm.value.number,
        subjectCode: [0],
        userStatus: 0,
        userType: 0,
        profile_url: '',
      };
      console.log('data:', data);
      this.api
        .parseApiCall(
          Constants.URL.TEACHER_SIGNUP,
          'POST',
          data,
          this.api.getCommonHeader()
        )
        .subscribe((res) => {
          console.log('res:', res);
          if (res.success) {
            console.log('teacher registration successful');
          } else {
            console.log('failed');
          }
        });
    } else {
      console.log('form is not valid');
    }
  }

  //For generating OTP
  public generateOtp() {
    console.log('otp:', this.otpGenerateForm.valid);

    if (this.otpGenerateForm.valid) {
      const data = {
        number: this.otpGenerateForm.value.number,
        appId: this.storageService.getLocalStorage(Constants.STRINGS.APP_ID),
      };
      console.log('data:', data);
      this.api
        .parseApiCall(
          Constants.URL.GENERATE_OTP,
          'POST',
          data,
          this.api.getCommonHeader()
        )
        .subscribe((res) => {
          console.log('res:', res);
          if (res.success) {
            console.log('otp generated successful');
          } else {
            console.log('failed');
          }
        });
    } else {
      console.log('form is not valid');
    }
  }

  //For verifying generated OTP
  public verifyOtp() {
    console.log('otp:', this.otpVerifyForm.valid);

    if (this.otpVerifyForm.valid) {
      const data = {
        number: this.otpVerifyForm.value.number,
        appId: this.storageService.getLocalStorage(Constants.STRINGS.APP_ID),
        otp: this.otpVerifyForm.value.otp,
      };
      console.log('data:', data);
      this.api
        .parseApiCall(
          Constants.URL.VERIFY_OTP,
          'POST',
          data,
          this.api.getCommonHeader()
        )
        .subscribe((res) => {
          console.log('res:', res);
          if (res.success) {
            this.storageService.setSessionStorage(
              Constants.STRINGS.TOKEN,
              res.data.token
            );
            this.storageService.setSessionStorage(
              Constants.STRINGS.USER_ID,
              res.data.userId
            );
            const userType = res.data.userType;
            this.storageService.setSessionStorage(
              Constants.STRINGS.USER_TYPE,
              userType
            );
            this.storageService.setSessionStorage(
              Constants.STRINGS.USERNAME,
              res.data.userName
            );
            if (userType === 0) {
              this.router.navigate(['/teacher/dashboard']);
            } else {
              this.router.navigate(['/student/dashboard']);
            }
          } else {
            console.log('failed');
          }
        });
    } else {
      console.log('form is not valid');
    }
  }

  //For check account
  public checkAccount() {
    console.log('otp:', this.checkAccountForm.valid);

    if (this.checkAccountForm.valid) {
      const data = {
        mobileNumber: this.checkAccountForm.value.mobileNumber,
      };
      console.log('data:', data);
      this.api
        .parseApiCall(
          Constants.URL.CHECK_ACCOUNT,
          'POST',
          data,
          this.api.getCommonHeader()
        )
        .subscribe((res) => {
          console.log('res:', res);
          if (res.success) {
            console.log('user not exists');
          } else {
            console.log('failed');
          }
        });
    } else {
      console.log('form is not valid');
    }
  }

  //For getting teacher dashboard details
  public getAllClassesTeacher() {
    const data = {
      Authorization: '',
      debug: '',
      userId: '',
    };
    this.api
      .parseApiCall(
        Constants.URL.GET_ALL_CLASSES_TEACHER,
        'GET',
        data,
        this.api.getCommonHeader()
      )
      .subscribe((res) => {
        console.log('res:', res);
        if (res.success) {
          console.log('user not exists');
        } else {
          console.log('failed');
        }
      });
  }
}
