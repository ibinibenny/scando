import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Constants } from 'src/app/constants/constants';
import { DataService } from 'src/app/services/data.service';
import { StorageService } from 'src/app/services/storage.service';

interface SubjectData {
  id: number;
  name: string;
}

@Component({
  selector: 'app-teacher-signup',
  templateUrl: './teacher-signup.component.html',
  styleUrls: ['./teacher-signup.component.css'],
})
export class TeacherSignupComponent implements OnInit {
  mobile!: string;
  profileUrl!: string;

  teacherRegForm = new FormGroup({
    userName: new FormControl(undefined, [
      Validators.required,
      Validators.minLength(3),
    ]),
    subjectCode: new FormControl(undefined, [
      Validators.required,
      Validators.min(1),
    ]),
  });
  nameForm = new FormGroup({
    userName: new FormControl(undefined, [
      Validators.required,
      Validators.minLength(3),
    ])
  });
  profileImageToUpload: any;
  subjects: SubjectData[] = [
    {
      id: 7000,
      name: 'Mathematics',
    },
    {
      id: 7001,
      name: 'English',
    },
    {
      id: 7002,
      name: 'Physics',
    },
    {
      id: 7003,
      name: 'Chemistry',
    },
    {
      id: 7004,
      name: 'Computer Science',
    },
  ];
  selectedSubjects: SubjectData[] = [];
  step = 2;

  constructor(
    private toastr: ToastrService,
    private route: ActivatedRoute,
    private storageService: StorageService,
    private dataService: DataService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe((res) => {
      const mobile = res.get('mobile');
      if (mobile) {
        this.mobile = mobile;
      }
    });
    this.teacherRegForm.controls.subjectCode.valueChanges.subscribe(
      (subject) => {
        this.subjectSelected(
          this.subjects.filter((single) => single.id == subject)[0]
        );
      }
    );
  }

  // For uploading user image for profile pic
  uploadPic() {
    if (this.profileImageToUpload) {
      const formData: FormData = new FormData();
      formData.append('file', this.profileImageToUpload);
      this.dataService
        .parseApiCall(
          Constants.URL.PROFILE_UPLOAD,
          'POST',
          formData,
          this.dataService.getCommonHeaderMultipart()
        )
        .subscribe((res) => {
          console.log('res:', res);
          if (res.success) {
            console.log('success:', res.success);
            this.profileUrl = res.data.profileUrl;
            this.teacherSignUp();
          } else {
            console.log('failed');
            this.toastr.error('Something went wrong, Please try again later');
          }
        });
    } else {
      console.log('no file');
      this.toastr.error('Please choose an image.');
    }
  }

  public readImage(event: any) {
    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (event1: any) => {
        this.profileImageToUpload = event.target.files[0];
      };
      reader.readAsDataURL(event.target.files[0]);
    }
  }

  // For teacher registrations
  public teacherSignUp() {
    console.log('otp:', this.teacherRegForm.valid);

    if (this.teacherRegForm.valid && this.selectedSubjects.length !== 0) {
      const data = {
        number: this.mobile,
        userStatus: 1,
        userType: 0,
        userName: this.teacherRegForm.value.userName,
        subjectCode: this.selectedSubjects.map((single) => {
          return single.id;
        }),
        profile_url: this.profileUrl ? this.profileUrl : '',
        appId: this.storageService.getLocalStorage(Constants.STRINGS.APP_ID),
      };
      console.log('data:', data);
      this.dataService
        .parseApiCall(
          Constants.URL.TEACHER_SIGNUP,
          'POST',
          data,
          this.dataService.getCommonHeader()
        )
        .subscribe((res) => {
          console.log('res:', res);
          if (res.success) {
            this.storageService.setSessionStorage(
              Constants.STRINGS.TOKEN,
              res.data.token
            );
            this.storageService.setSessionStorage(
              Constants.STRINGS.USER_ID,
              res.data.userId
            );
            const userType = res.data.userType;
            this.storageService.setSessionStorage(
              Constants.STRINGS.USER_TYPE,
              userType
            );
            this.storageService.setSessionStorage(
              Constants.STRINGS.USERNAME,
              res.data.userName
            );
            this.router.navigate(['/modify-class/create-class', 1]);
          } else {
            console.log('failed');
          }
        });
    } else {
      console.log('form is not valid');
      this.toastr.error(
        'Teacher registration form is not valid, username and subject filed is mandatory.'
      );
    }
  }

  public submitClicked() {
    if (this.profileImageToUpload) {
      this.uploadPic();
    } else {
      this.teacherSignUp();
    }
  }

  public subjectSelected(subject: SubjectData) {
    if (!this.selectedSubjects.includes(subject)) {
      this.selectedSubjects.push(subject);
    }
  }

  public nameFormSubmited() {
    if (this.nameForm.valid) {
      this.step = 2;
      this.teacherRegForm.patchValue({userName: this.nameForm.value.userName});
    } else {
      this.toastr.warning('Enter a valid name');
    }
  }

}
