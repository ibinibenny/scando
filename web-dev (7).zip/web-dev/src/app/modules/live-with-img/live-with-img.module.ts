import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LiveWithImgRoutingModule } from './live-with-img-routing.module';
import { LiveWithImgComponent } from './live-with-img/live-with-img.component';


@NgModule({
  declarations: [
    LiveWithImgComponent
  ],
  imports: [
    CommonModule,
    LiveWithImgRoutingModule
  ]
})
export class LiveWithImgModule { }
