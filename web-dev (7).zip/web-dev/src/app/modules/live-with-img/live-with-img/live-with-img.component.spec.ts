import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LiveWithImgComponent } from './live-with-img.component';

describe('LiveWithImgComponent', () => {
  let component: LiveWithImgComponent;
  let fixture: ComponentFixture<LiveWithImgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LiveWithImgComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LiveWithImgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
