import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-live-with-img',
  templateUrl: './live-with-img.component.html',
  styleUrls: ['./live-with-img.component.css']
})
export class LiveWithImgComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
