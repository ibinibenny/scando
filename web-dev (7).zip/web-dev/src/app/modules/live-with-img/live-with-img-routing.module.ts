import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LiveWithImgComponent } from './live-with-img/live-with-img.component';

const routes: Routes = [
  {
    path: 'Live-with-img',
    pathMatch: 'full',
    component: LiveWithImgComponent
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LiveWithImgRoutingModule { }
