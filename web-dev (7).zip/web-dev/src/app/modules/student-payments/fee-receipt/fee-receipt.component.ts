import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Constants } from 'src/app/constants/constants';
import { ReceiptData } from 'src/app/interfaces/receipt-data';
import { DataService } from 'src/app/services/data.service';
import { NavigationService } from 'src/app/services/navigation.service';

import * as html2canvas from 'html2canvas';

@Component({
  selector: 'app-fee-receipt',
  templateUrl: './fee-receipt.component.html',
  styleUrls: ['./fee-receipt.component.css']
})
export class FeeReceiptComponent implements OnInit {

  receiptData: ReceiptData;
  @ViewChild('screen') screen: ElementRef;
  @ViewChild('canvas') canvas: ElementRef;
  @ViewChild('downloadLink') downloadLink: ElementRef;

  constructor(
    private dataService: DataService,
    private route: ActivatedRoute,
    public navService: NavigationService,
  ) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(res => {
      const orderId = res.get('orderId');
      if (orderId) {
        this.getReceipt(orderId);
      }
    })
  }

  public getReceipt(orderId: string) {
    this.dataService.parseApiCall(
      `${Constants.URL.GET_RECEIPT}/${orderId}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.receiptData = res.data;
      }
    });
  }

  public print() {
    window.print();
  }

  public downloadAsPDF() {
    html2canvas(this.screen.nativeElement).then(canvas => {
      this.canvas.nativeElement.src = canvas.toDataURL();
      this.downloadLink.nativeElement.href = canvas.toDataURL('image/png');
      this.downloadLink.nativeElement.download = 'receipt.png';
      this.downloadLink.nativeElement.click();
    });
  }

  share() {
    html2canvas(this.screen.nativeElement).then(async canvas => {
      let newVariable: any;
      newVariable = window.navigator;
      const dataUrl = canvas.toDataURL();
      const blob = await (await fetch(dataUrl)).blob();
      const filesArray = [new File([blob], 'receipt.png', { type: blob.type })];
      if (newVariable.canShare && newVariable.canShare({ files: filesArray })) {
        newVariable.share({
          files: filesArray,
          title: 'Vacation Pictures',
          text: 'Photos from September 27 to October 14.',
        })
        .then(() => console.log('Share was successful.'))
        .catch((error) => console.log('Sharing failed', error));
      } else {
        console.log(`Your system doesn't support sharing files.`);
      }
    });
  }

}
