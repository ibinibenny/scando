import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StudentPaymentsRoutingModule } from './student-payments-routing.module';
import { GlobalModule } from '../global/global.module';
import { FeeReceiptComponent } from './fee-receipt/fee-receipt.component';
import { MyFeepaymentComponent } from './my-feepayment/my-feepayment.component';
import { StudentPaymentComponent } from './student-payment/student-payment.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FlutterwaveModule } from 'flutterwave-angular-v3';


@NgModule({
  declarations: [
    FeeReceiptComponent,
    MyFeepaymentComponent,
    StudentPaymentComponent,
  ],
  imports: [
    CommonModule,
    StudentPaymentsRoutingModule,
    GlobalModule,
    NgbModule,
    FlutterwaveModule,
  ]
})
export class StudentPaymentsModule { }
