import { Component, OnInit } from '@angular/core';
import { Constants } from 'src/app/constants/constants';
import { StudentPaymentData } from 'src/app/interfaces/student-payment-data';
import { DataService } from 'src/app/services/data.service';
import { NavigationService } from 'src/app/services/navigation.service';

@Component({
  selector: 'app-my-feepayment',
  templateUrl: './my-feepayment.component.html',
  styleUrls: ['./my-feepayment.component.css']
})
export class MyFeepaymentComponent implements OnInit {

  apiFilters = {
    startTime: 0,
    endTime: Date.now(),
    limit: 100,
    page: 1
  };
  payments: StudentPaymentData[] = [];

  constructor(
    private dataService: DataService,
    public navService: NavigationService,
  ) { }

  ngOnInit(): void {
    this.getPayments();
  }

  public getPayments() {
    this.dataService.parseApiCall(
      `${Constants.URL.GET_SELF_PAYMENTS}?${new URLSearchParams(this.apiFilters as any)}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.payments = res.data.list;
      } else {
        this.payments = [];
      }
    });
  }

}
