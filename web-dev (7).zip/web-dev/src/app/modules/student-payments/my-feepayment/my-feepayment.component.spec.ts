import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyFeepaymentComponent } from './my-feepayment.component';

describe('MyFeepaymentComponent', () => {
  let component: MyFeepaymentComponent;
  let fixture: ComponentFixture<MyFeepaymentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyFeepaymentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyFeepaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
