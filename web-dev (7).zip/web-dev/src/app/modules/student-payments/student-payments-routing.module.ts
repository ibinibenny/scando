import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FeeReceiptComponent } from './fee-receipt/fee-receipt.component';
import { MyFeepaymentComponent } from './my-feepayment/my-feepayment.component';
import { StudentPaymentComponent } from './student-payment/student-payment.component';

const routes: Routes = [
  {
    path: 'fee-receipt/:orderId',
    component: FeeReceiptComponent
  },
  {
    path: 'my-fee-payment',
    component: MyFeepaymentComponent
  },
  {
    path: 'student-payment/:classId',
    component: StudentPaymentComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StudentPaymentsRoutingModule { }
