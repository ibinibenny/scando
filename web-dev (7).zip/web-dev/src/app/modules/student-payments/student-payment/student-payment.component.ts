import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Flutterwave, InlinePaymentOptions, PaymentSuccessResponse } from 'flutterwave-angular-v3';
import { Constants } from 'src/app/constants/constants';
import { ClassPaymentData } from 'src/app/interfaces/class-payment-data';
import { DataService } from 'src/app/services/data.service';
import { NavigationService } from 'src/app/services/navigation.service';
import { StorageService } from 'src/app/services/storage.service';

@Component({
  selector: 'app-student-payment',
  templateUrl: './student-payment.component.html',
  styleUrls: ['./student-payment.component.css']
})
export class StudentPaymentComponent implements OnInit {

  paymentDetails: ClassPaymentData;
  publicKey = Constants.FLUTTERWAVE.PUBLIC_KEY;
  customerDetails = {
    name: null,
    email: 'tech@scando.world',
    phone_number: null,
  };
  customizations = {
    title: "Pay for scando",
    description: "Pay for your scando classes",
    logo: "https://flutterwave.com/images/logo-colored.svg",
  };
  meta = { counsumer_id: "7898", consumer_mac: "kjs9s8ss7dd" };

  constructor(
    private dataService: DataService,
    private route: ActivatedRoute,
    private storageService: StorageService,
    private flutterwave: Flutterwave,
    private router: Router,
    public navService: NavigationService
  ) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(res => {
      const classId = res.get('classId');
      if (classId) {
        this.getPaymentDetails(classId);
      }
    });
    this.customerDetails.name = this.storageService.getSessionStorage(Constants.STRINGS.USERNAME);
    this.customerDetails.phone_number = this.storageService.getSessionStorage('PHONE_NUMBER').e164Number;
  }

  public getPaymentDetails(classId: string) {
    this.dataService.parseApiCall(
      `${Constants.URL.GET_PAYMENT_DETAILS}?classId=${classId}`,
      'GET',
      null,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        this.paymentDetails = res.data;
      }
    });
  }

  makePaymentCallback(response: PaymentSuccessResponse): void {
    console.log("Pay", response);
    if (response.status === 'successful') {
      this.updateOrderId(response.tx_ref, 'card');
    }
    this.flutterwave.closePaymentModal(5);
  }

  closedPaymentModal(): void {
    console.log("payment is closed");
  }

  generateReference(): string {
    let date = new Date();
    return date.getTime().toString();
  }

  public createOrderId(classData: ClassPaymentData) {
    const data = {
      "classId": classData.classId,
      "amount": classData.total,
      "description": "This payment id done via .."
    }
    this.dataService.parseApiCall(
      Constants.URL.CREATE_ORDER_ID,
      'POST',
      data,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      if (res.success) {
        const paymentData: InlinePaymentOptions = {
          public_key: this.publicKey,
          tx_ref: res.data.orderId,
          amount: classData.total,
          currency: "NGN",
          payment_options: "card",
          redirect_url: '',
          customer: this.customerDetails,
          customizations: this.customizations,
          callback: this.makePaymentCallback,
          onclose: this.closedPaymentModal,
          callbackContext: this
        };
        this.flutterwave.inlinePay(paymentData);
      }
    });
  }

  public updateOrderId(orderId: string, paymentChannel: string) {
    const data = {
      "orderId": orderId,
      "status": 1,
      "paymentChannel": paymentChannel
    }
    this.dataService.parseApiCall(
      Constants.URL.UPDATE_ORDER_ID,
      'PUT',
      data,
      this.dataService.getTokenHeader()
    ).subscribe(res => {
      this.router.navigate(['/student/class']);
    });
  }

}
