export const environment = {
  production: true,
  API_URL: 'http://dev.scando.world:8080/api',
  ADMIN_API_URL: 'http://dev.scando.world:8083/api'
};
